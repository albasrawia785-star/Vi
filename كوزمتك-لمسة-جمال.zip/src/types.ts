/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Category {
  id: string;
  name: string;
  icon: string; // Material Symbol icon name
  createdAt: number;
}

export interface Product {
  id: string;
  name: string;
  brand: string;
  categoryId: string;
  price: number; // Positive integer
  quantity: number; // Non-negative integer
  lowStockThreshold: number; // Non-negative integer
  description?: string;
  image?: string; // Base64 compressed image
  barcode?: string;
  createdAt: number;
}

export interface SaleItem {
  productId: string;
  name: string;
  brand: string;
  price: number;
  quantity: number;
  total: number;
}

export interface SaleTransaction {
  id: string; // Auto-increment style e.g. "#0001"
  orderNum: number; // Numerical value for sequencing
  timestamp: number;
  items: SaleItem[];
  totalAmount: number;
  shiftId?: string; // Reference to the POS Shift in which this sale occurred
}

export interface POSShift {
  id: string;
  startTime: number;
  endTime?: number;
  startBalance: number;
  endBalance?: number;
  status: "open" | "closed";
  salesCount: number;
  salesTotal: number;
}

export interface StoreSettings {
  defaultLowStockThreshold: number;
  marketingText: string;
  onboardingCompleted: boolean;
}

export type ActiveTab = 'sale' | 'products' | 'categories' | 'history' | 'reports' | 'settings' | 'shifts';

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Product, Category } from "../../types";
import ProductImage from "../../components/ProductImage";
import { APP_CONFIG } from "../../config";
import { getProductsPaged } from "../../database/products";

interface ProductsAdminProps {
  products: Product[];
  categories: Category[];
  onAddProduct: () => void;
  onEditProduct: (product: Product) => void;
  onDeleteProduct: (id: string) => void;
  cosmeticName?: string;
  productsRevision?: number; // Force update when DB changes
  totalProductsCount?: number;
}

type StockFilter = "all" | "available" | "low_stock" | "out_of_stock";

const ITEMS_PER_PAGE = 30;

export default function ProductsAdmin({
  products,
  categories,
  onAddProduct,
  onEditProduct,
  onDeleteProduct,
  cosmeticName,
  productsRevision = 0,
  totalProductsCount = 0
}: ProductsAdminProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [stockFilter, setStockFilter] = useState<StockFilter>("all");
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // local paginated products states
  const [localProducts, setLocalProducts] = useState<Product[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [hasMore, setHasMore] = useState(false);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);

  const loadMoreRef = useRef<HTMLDivElement>(null);

  const activeCosmeticName = cosmeticName || "كوزمتك لمسة جمال";

  // Debounce search input (300ms) to avoid over-querying IndexedDB
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(searchQuery);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Load initial products when filter parameters or revision triggers change
  useEffect(() => {
    let active = true;
    async function fetchInitial() {
      setLoading(true);
      try {
        const res = await getProductsPaged({
          searchQuery: debouncedQuery,
          stockFilter,
          offset: 0,
          limit: ITEMS_PER_PAGE
        });
        if (active) {
          setLocalProducts(res.products);
          setTotalCount(res.totalCount);
          setHasMore(res.hasMore);
          setPage(1);
        }
      } catch (err) {
        console.error("Error loading products in ProductsAdmin:", err);
      } finally {
        if (active) setLoading(false);
      }
    }
    fetchInitial();
    return () => {
      active = false;
    };
  }, [debouncedQuery, stockFilter, productsRevision]);

  // Load more on scroll
  const handleLoadMore = async () => {
    if (loading || !hasMore) return;
    setLoading(true);
    try {
      const nextPage = page + 1;
      const res = await getProductsPaged({
        searchQuery: debouncedQuery,
        stockFilter,
        offset: (nextPage - 1) * ITEMS_PER_PAGE,
        limit: ITEMS_PER_PAGE
      });
      setLocalProducts((prev) => {
        const existingIds = new Set(prev.map((p) => p.id));
        const filteredNew = res.products.filter((p) => !existingIds.has(p.id));
        return [...prev, ...filteredNew];
      });
      setTotalCount(res.totalCount);
      setHasMore(res.hasMore);
      setPage(nextPage);
    } catch (err) {
      console.error("Error loading more products in ProductsAdmin:", err);
    } finally {
      setLoading(false);
    }
  };

  // IntersectionObserver for lazy loading
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !loading) {
          handleLoadMore();
        }
      },
      { threshold: 0.1 }
    );

    const currentLoadMore = loadMoreRef.current;
    if (currentLoadMore) {
      observer.observe(currentLoadMore);
    }

    return () => {
      if (currentLoadMore) {
        observer.unobserve(currentLoadMore);
      }
    };
  }, [hasMore, loading, page, stockFilter, debouncedQuery]);

  // Map categories for easier lookup
  const categoryNames = useMemo(() => {
    const map: { [key: string]: string } = {};
    categories.forEach((cat) => {
      map[cat.id] = cat.name;
    });
    return map;
  }, [categories]);

  const formatPrice = (price: number) => {
    return price.toLocaleString("en-US") + " " + APP_CONFIG.currency;
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden pb-16 text-right" dir="rtl">
      {/* Search & Actions Panel */}
      <div className="p-4 bg-white border-b border-slate-100 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-slate-800">إدارة مستودع المنتجات</h2>
              <span className="text-[10px] font-extrabold text-rose-500 bg-rose-50 px-2 py-0.5 rounded-full border border-rose-100/40 shrink-0">
                {totalProductsCount} منتج كلي
              </span>
            </div>
            <p className="text-xs text-slate-400 font-medium">إضافة، تعديل وحذف منتجات {activeCosmeticName}</p>
          </div>

          <button
            id="btn-admin-add-product"
            onClick={onAddProduct}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-rose-500 hover:bg-rose-600 text-white rounded-2xl font-bold text-xs shadow-md shadow-rose-200 transition-all active:scale-95 shrink-0 cursor-pointer"
          >
            <span className="material-symbols-outlined !text-lg">add</span>
            منتج جديد
          </button>
        </div>

        {/* Search */}
        <div className="relative">
          <input
            id="admin-search-input"
            type="text"
            placeholder="ابحث عن منتج بالمخزون..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pr-11 pl-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-rose-500 transition-all font-medium text-slate-800 text-right"
          />
          <span className="material-symbols-outlined absolute top-3 right-4 text-slate-400 !text-xl pointer-events-none">
            search
          </span>
          {searchQuery && (
            <button
              id="admin-search-clear"
              onClick={() => setSearchQuery("")}
              className="absolute top-3 left-4 text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
            >
              <span className="material-symbols-outlined !text-base">close</span>
            </button>
          )}
        </div>

        {/* Status filters */}
        <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
          {(
            [
              { id: "all", label: "الكل" },
              { id: "available", label: "المتوفرة" },
              { id: "low_stock", label: "قليلة المخزون" },
              { id: "out_of_stock", label: "النافدة" }
            ] as const
          ).map((filter) => (
            <button
              key={filter.id}
              id={`stock-filter-${filter.id}`}
              onClick={() => setStockFilter(filter.id)}
              className={`px-4 py-2 rounded-xl text-[11px] font-bold shrink-0 transition-all cursor-pointer ${
                stockFilter === filter.id
                  ? "bg-rose-500 text-white"
                  : "bg-slate-100 text-slate-600 hover:bg-slate-200"
              }`}
            >
              {filter.label}
            </button>
          ))}
        </div>
      </div>

      {/* Products Grid Content Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
        {localProducts.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <span className="material-symbols-outlined text-slate-300 !text-6xl mb-2">inventory</span>
            <p className="text-sm font-bold text-slate-600">المخزن فارغ أو لا توجد نتائج</p>
            <p className="text-xs text-slate-400 mt-1 max-w-xs leading-relaxed">
              انقر على "منتج جديد" في الأعلى لإضافة أول منتج وتعبئة مستودع {activeCosmeticName}.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {localProducts.map((prod) => {
              const isOutOfStock = prod.quantity <= 0;
              const isLowStock = prod.quantity > 0 && prod.quantity <= prod.lowStockThreshold;

              return (
                <div
                  key={prod.id}
                  id={`admin-product-card-${prod.id}`}
                  className="bg-white rounded-2xl border border-slate-100 shadow-xs p-3.5 flex items-center justify-between gap-4"
                >
                  {/* Thumbnail */}
                  <div className="relative w-16 h-20 rounded-xl overflow-hidden bg-slate-50 shrink-0 border border-slate-100">
                    <ProductImage image={prod.image} categoryId={prod.categoryId} name={prod.name} />
                  </div>

                  {/* Text Details */}
                  <div className="flex-1 min-w-0 text-right">
                    <div className="flex items-center gap-1.5 flex-wrap justify-start">
                      <span className="text-[10px] font-bold text-[#7B0F3A] bg-[#7B0F3A]/5 border border-[#7B0F3A]/15 px-2 py-0.5 rounded-md">
                        {categoryNames[prod.categoryId] || "غير مصنف"}
                      </span>
                      {isOutOfStock ? (
                        <span className="text-[9px] font-black text-rose-500 bg-rose-50 px-2 py-0.5 rounded animate-pulse">
                          نفد
                        </span>
                      ) : isLowStock ? (
                        <span className="text-[9px] font-black text-amber-500 bg-amber-50 px-2 py-0.5 rounded animate-pulse">
                          قليل المخزون
                        </span>
                      ) : null}
                    </div>

                    <h3 className="font-bold text-sm text-slate-800 mt-1 truncate" title={prod.name}>
                      {prod.name}
                    </h3>
                    <p className="text-[10px] text-slate-400 font-semibold">{prod.brand}</p>

                    <div className="flex items-center gap-3 mt-1.5 justify-end">
                      <span className="text-[11px] font-bold text-slate-500">
                        المخزون: <span className={isOutOfStock ? "text-rose-500 font-extrabold" : isLowStock ? "text-amber-500 font-extrabold" : "text-slate-700"}>{prod.quantity} قطعة</span>
                      </span>
                      <span className="text-xs font-black text-rose-500">
                        {formatPrice(prod.price)}
                      </span>
                    </div>
                  </div>

                  {/* Actions buttons */}
                  <div className="flex flex-col gap-1 shrink-0">
                    <button
                      id={`btn-admin-edit-${prod.id}`}
                      onClick={() => onEditProduct(prod)}
                      className="w-9 h-9 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
                      title="تعديل المنتج"
                    >
                      <span className="material-symbols-outlined !text-lg">edit</span>
                    </button>
                    <button
                      id={`btn-admin-delete-${prod.id}`}
                      onClick={() => setDeleteConfirmId(prod.id)}
                      className="w-9 h-9 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-500 flex items-center justify-center transition-colors cursor-pointer"
                      title="حذف المنتج"
                    >
                      <span className="material-symbols-outlined !text-lg">delete</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Lazy load sensor element */}
        {hasMore && (
          <div ref={loadMoreRef} className="flex justify-center py-4">
            <span className="animate-spin material-symbols-outlined text-rose-500 !text-2xl">sync</span>
          </div>
        )}
      </div>

      {/* Confirmation Modal for delete */}
      <AnimatePresence>
        {deleteConfirmId && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-slate-900/40 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-xl text-center space-y-4 border border-slate-100"
            >
              <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center mx-auto">
                <span className="material-symbols-outlined !text-3xl">warning</span>
              </div>
              <div>
                <h4 className="font-bold text-slate-800">حذف المنتج نهائياً؟</h4>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  هل أنت متأكد من رغبتك في حذف هذا المنتج من المخزن؟ لا يمكن التراجع عن هذه الخطوة.
                </p>
              </div>
              <div className="flex gap-3 pt-2">
                <button
                  id="btn-confirm-delete-yes"
                  onClick={() => {
                    onDeleteProduct(deleteConfirmId);
                    setDeleteConfirmId(null);
                  }}
                  className="flex-1 py-2.5 bg-rose-500 hover:bg-rose-600 text-white rounded-xl font-bold text-xs transition-colors cursor-pointer"
                >
                  نعم، حذف المنتج
                </button>
                <button
                  id="btn-confirm-delete-no"
                  onClick={() => setDeleteConfirmId(null)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl font-bold text-xs transition-colors cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import { AlertTriangle, RefreshCw, KeyRound, Smartphone } from "lucide-react";
import { getDeviceId } from "../../services/license-service";

interface LicenseLockedScreenProps {
  message: string;
  onRetry: () => void;
  isChecking: boolean;
}

export default function LicenseLockedScreen({ message, onRetry, isChecking }: LicenseLockedScreenProps) {
  const currentDevice = getDeviceId();

  return (
    <div className="flex-1 flex flex-col justify-center items-center p-6 bg-slate-50 h-full select-none text-right">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-md bg-white rounded-[32px] border border-red-100 p-8 shadow-xl space-y-6 text-right"
      >
        {/* Warning Icon */}
        <div className="flex flex-col items-center text-center space-y-2">
          <div className="w-16 h-16 bg-red-50 rounded-2xl flex items-center justify-center text-red-500 shadow-inner">
            <AlertTriangle className="w-10 h-10" />
          </div>
          <h2 className="text-lg font-black text-slate-800 font-sans mt-2">
            خطأ في تفعيل البرنامج
          </h2>
          <p className="text-[11px] text-slate-400 font-medium">
            يرجى مراجعة موفر الخدمة لتفعيل الترخيص الخاص بك
          </p>
        </div>

        {/* Error message card */}
        <div className="bg-red-50/50 border border-red-100 rounded-2xl p-4 text-center">
          <p className="text-xs font-bold text-red-800 leading-relaxed">
            {message}
          </p>
        </div>

        {/* Device Information section */}
        <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 space-y-2 text-right">
          <div className="flex items-center justify-between text-[11px]">
            <span className="font-mono text-slate-700 bg-slate-200/60 px-2 py-0.5 rounded-md select-all">
              {currentDevice}
            </span>
            <span className="font-bold text-slate-500 flex items-center gap-1.5">
              <span>معرف الجهاز الحالي</span>
              <Smartphone className="w-3.5 h-3.5 text-slate-400" />
            </span>
          </div>
          <p className="text-[10px] text-slate-400 leading-normal">
            * هذا المعرف فريد ومربوط بترخيصك لتأمين الحساب من النسخ غير المصرح به.
          </p>
        </div>

        {/* Retry Button */}
        <button
          onClick={onRetry}
          disabled={isChecking}
          className="w-full py-3.5 bg-red-600 hover:bg-red-700 disabled:bg-slate-300 text-white font-bold rounded-xl shadow-lg shadow-red-100 hover:shadow-red-200 active:scale-95 transition-all text-xs cursor-pointer flex items-center justify-center gap-2"
        >
          {isChecking ? (
            <RefreshCw className="w-4 h-4 animate-spin" />
          ) : (
            <KeyRound className="w-4 h-4" />
          )}
          <span>أعد التحقق من الترخيص (أونلاين)</span>
        </button>
      </motion.div>
    </div>
  );
}

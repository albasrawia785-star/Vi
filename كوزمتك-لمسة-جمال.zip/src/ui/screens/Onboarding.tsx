/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";

interface OnboardingProps {
  onComplete: () => void;
}

const SLIDES = [
  {
    title: "سهولة وسرعة البيع",
    description: "اضغط على أي منتج لإضافته مباشرة إلى سلة المبيعات. يمكنك تعديل الكميات أو حذفها بكل سهولة من خلال السلة العائمة المريحة.",
    icon: "shopping_bag",
    color: "from-rose-400 to-pink-500"
  },
  {
    title: "إدارة متكاملة للمنتجات",
    description: "أضف منتجاتك بكافة تفاصيلها: الاسم، السعر، الفئة، والكمية المتوفرة. مع ميزة إرفاق صور حقيقية من الكاميرا أو المعرض مباشرة وضغطها تلقائياً.",
    icon: "inventory_2",
    color: "from-pink-500 to-rose-600"
  },
  {
    title: "مراقبة المخزون والتقارير",
    description: "تتبع حالة المخزون بذكاء مع تنبيهات تلقائية للمنتجات منخفضة الكمية. استعرض تقارير المبيعات اليومية والشهرية والإجماليات بدقة متناهية.",
    icon: "analytics",
    color: "from-rose-600 to-brand-700"
  }
];

export default function Onboarding({ onComplete }: OnboardingProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const handleNext = () => {
    if (currentSlide < SLIDES.length - 1) {
      setCurrentSlide(prev => prev + 1);
    } else {
      onComplete();
    }
  };

  const handlePrev = () => {
    if (currentSlide > 0) {
      setCurrentSlide(prev => prev - 1);
    }
  };

  return (
    <div id="onboarding-container" className="fixed inset-0 z-40 bg-white flex flex-col justify-between overflow-hidden text-right" dir="rtl">
      {/* Skip button at top */}
      <div className="flex justify-between items-center px-6 pt-6 pb-2">
        <span className="text-xs font-semibold px-3 py-1 bg-rose-50 text-rose-500 rounded-full">
          دليل التشغيل السريع
        </span>
        {currentSlide < SLIDES.length - 1 && (
          <button
            id="btn-skip-onboarding"
            onClick={onComplete}
            className="text-sm font-semibold text-slate-400 hover:text-rose-500 transition-colors cursor-pointer"
          >
            تخطي
          </button>
        )}
      </div>

      {/* Main slides carousel with slide transitions */}
      <div className="flex-1 flex flex-col justify-center px-8 relative">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide}
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 50 }}
            transition={{ duration: 0.4, ease: "easeOut" }}
            className="flex flex-col items-center text-center animate-none"
          >
            {/* Visual Icon card with gradient backdrop */}
            <div className={`w-40 h-40 rounded-3xl bg-gradient-to-tr ${SLIDES[currentSlide].color} flex items-center justify-center text-white shadow-lg mb-8`}>
              <span className="material-symbols-outlined !text-7xl">
                {SLIDES[currentSlide].icon}
              </span>
            </div>

            {/* Title */}
            <h2 className="text-2xl font-bold text-slate-800 mb-4">
              {SLIDES[currentSlide].title}
            </h2>

            {/* Description */}
            <p className="text-slate-500 text-sm leading-relaxed max-w-sm">
              {SLIDES[currentSlide].description}
            </p>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Bottom navigation slide indicators and actions */}
      <div className="p-8 flex flex-col gap-6 bg-slate-50/50 border-t border-slate-100">
        {/* Progress dots */}
        <div className="flex justify-center gap-2">
          {SLIDES.map((_, index) => (
            <div
              key={index}
              className={`h-2.5 rounded-full transition-all duration-300 ${
                index === currentSlide ? "w-8 bg-rose-500" : "w-2.5 bg-slate-200"
              }`}
            />
          ))}
        </div>

        {/* Buttons */}
        <div className="flex gap-4 items-center">
          {currentSlide > 0 ? (
            <button
              id="btn-onboarding-prev"
              onClick={handlePrev}
              className="flex-1 py-3.5 border border-slate-200 text-slate-600 rounded-2xl font-semibold hover:bg-slate-50 active:scale-95 transition-all text-center text-sm cursor-pointer"
            >
              السابق
            </button>
          ) : null}

          <button
            id="btn-onboarding-next"
            onClick={handleNext}
            className="flex-[2] py-3.5 bg-rose-500 hover:bg-rose-600 active:scale-95 text-white rounded-2xl font-semibold shadow-md shadow-rose-200 transition-all text-center text-sm cursor-pointer"
          >
            {currentSlide === SLIDES.length - 1 ? "ابدأ الاستخدام الآن" : "التالي"}
          </button>
        </div>
      </div>
    </div>
  );
}

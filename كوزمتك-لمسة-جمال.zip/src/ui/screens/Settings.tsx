/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent } from "react";
import { motion, AnimatePresence } from "motion/react";
import { StoreSettings, POSShift, SaleTransaction, Product, Category } from "../../types";
import { APP_CONFIG } from "../../config";
import SalesHistory from "../../components/SalesHistory";
import Reports from "../../components/Reports";
import ShiftsAdmin from "../../components/ShiftsAdmin";
import CustomersAdmin from "./CustomersAdmin";
import { LogOut } from "lucide-react";

interface SettingsProps {
  settings: StoreSettings;
  onSaveSettings: (settings: StoreSettings) => void;
  onResetDatabase: () => void;
  
  // Sub-views props
  shifts: POSShift[];
  sales: SaleTransaction[];
  activeShift: POSShift | null;
  onOpenShift: (startBalance: number) => Promise<void>;
  onCloseShift: (endBalance: number) => Promise<void>;
  onDeleteShift?: (id: string) => Promise<void>;
  onDeleteSale?: (id: string) => void;
  products: Product[];
  categories: Category[];
  onBulkSaveProducts: (productsList: Product[]) => Promise<void>;
  productsRevision?: number;

  // Navigation coordination
  activeSubTab: string;
  onSubTabChange: (subTab: string) => void;

  // Manager authentication props
  onLogout?: () => void;
  currentUser?: { username: string; role: "manager" | "cashier" } | null;
  cosmeticName?: string;
}

export default function Settings({
  settings,
  onSaveSettings,
  onResetDatabase,
  shifts,
  sales,
  activeShift,
  onOpenShift,
  onCloseShift,
  onDeleteShift,
  onDeleteSale,
  products,
  categories,
  onBulkSaveProducts,
  productsRevision = 0,
  activeSubTab,
  onSubTabChange,
  onLogout,
  currentUser,
  cosmeticName
}: SettingsProps) {
  const [defaultLowStock, setDefaultLowStock] = useState<number>(settings.defaultLowStockThreshold);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);

  const activeCosmeticName = cosmeticName || "كوزمتك لمسة جمال";

  const handleSave = (e: FormEvent) => {
    e.preventDefault();
    onSaveSettings({
      ...settings,
      defaultLowStockThreshold: defaultLowStock,
      marketingText: ""
    });
    setSuccessMsg("تم حفظ الإعدادات بنجاح!");
    setTimeout(() => setSuccessMsg(""), 3000);
  };

  const handleResetConfirm = () => {
    onResetDatabase();
    setShowResetConfirm(false);
    setSuccessMsg("تمت إعادة تعيين النظام بالكامل بنجاح!");
    setTimeout(() => setSuccessMsg(""), 3000);
  };

  const handleGenerateMockProducts = async () => {
    setIsGenerating(true);
    try {
      const brands = ["شانيل", "ديور", "ميبيلين", "لوريال", "ماك", "كلينيك", "سيرافي", "فنتي بيوتي", "هدى بيوتي", "ذا أوردينري", "نيكس", "سيفورا"];
      const categoryTemplates: Record<string, string[]> = {
        perfumes: ["عطر نسائي فاخر", "عطر رجالي فواح", "بودي سبلاش منعش", "زيت عطري مركز", "بخور ملكي فاخر", "معطر مفرش ملكي"],
        skin_care: ["سيروم مغذي للبشرة", "غسول لطيف للوجه", "تونر موازن", "قناع مرطب عميق", "مقشر لطيف خلايا الميتة", "سيروم الهيالورونيك"],
        face_creams: ["كريم مرطب يومي", "كريم ليلي مغذي", "كريم النهار الواقي", "كريم الكولاجين لشد البشرة", "كريم تفتيح البشرة"],
        sunscreen: ["واقي شمس فيزيائي", "واقي شمس سائل خفيف", "جل واقي من الشمس", "كريم حماية ضد التجاعيد", "لوشن واقي شمس"],
        lipsticks: ["أحمر شفاه مطفي ثبات طويل", "ملمع شفاه مرطب", "حمرة سائلة مخملية", "مرطب شفاه بنكهة الكرز", "تنت شفاة وخدود"],
        makeup_pencils: ["قلم تحديد شفاة دقيق", "قلم حواجب شعرة شعرة", "محدد عيون ضد الماء", "كحل بيجي داخل العين"],
        mascara: ["ماسكارا تكثيف الرموش", "ماسكارا تطويل وتحديد", "ماسكارا شفافة ومغذية", "ماسكارا رموش ضد الماء"],
        eyeliner: ["آيلاينر سائل أسود فاحم", "قلم آيلاينر كحل ثابت", "آيلاينر مقاوم للتعرق", "آيلاينر جل مع ريشة"],
        kohl: ["كحل عربي طبيعي أسود", "كحل ملون ضد الماء", "قلم كحل كريمي ناعم", "كحل سواد فاحم"],
        eyeshadow: ["باليت ظلال عيون ترابي", "ظلال عيون برونزية لامعة", "باليت آيشادو ألوان صيفية", "إضاءة عيون ميتاليك"],
        foundation: ["كريم أساس تغطية كاملة", "كريم أساس مخملي يومي", "كريم أساس طبي خفيف", "بي بي كريم حماية ومكياج"],
        concealer: ["كونسيلر إخفاء العيوب", "كونسيلر إضاءة تحت العين", "مصحح عيوب سائل", "كونسيلر تغطية كاملة"],
        powder: ["بودرة مضغوطة مخملية", "بودرة حرة شفافة للوجه", "بودرة تثبيت المكياج", "بودرة وجه مخملية"],
        blusher: ["بلاشر بودرة خوخي", "بلاشر كريمي وردي منعش", "أحمر خدود سائل", "بلاشر برونزي دافئ"],
        contour: ["باليت كونتور وهايلايت", "ستيك كونتور لتحديد الوجه", "بودرة كونتور نحت الملامح", "كونتور سائل نحت الخدود"],
        highlighter: ["هايلايتر سائل متوهج", "بودرة إضاءة ذهبية", "هايلايتر كريمي ناعم", "إضاءة وجه ماسية"],
        makeup_fixer: ["مثبت مكياج مطفي طويل الأمد", "بخاخ تثبيت المكياج المرطب", "مثبت مكياج بلمسة لامعة", "سبراي منعش للمكياج"],
        primer: ["برايمر تصغير المسام", "برايمر مرطب للبشرة الجافة", "برايمر مطفي للتحكم بالزيوت", "برايمر نضارة وإضاءة"],
        hair_care: ["سيروم الأرغان لتغذية الشعر", "ماسك معالج للشعر التالف", "زيت مقوي لبصيلات الشعر", "بديل زيت مغذي لجميع أنواع الشعر", "امبولات تساقط الشعر"],
        shampoo_conditioner: ["شامبو مرطب بخلاصة الصبار", "بلسم منعم للشعر المصبوغ", "شامبو حماية الكيراتين", "شامبو خالي من السلفات لغسيل لطيف", "بلسم معالج بجوز الهند"],
        hair_dyes: ["صبغة شعر أشقر رمادي", "صبغة شعر بني شوكولاتة", "صبغة شعر أحمر ناري", "كريم صبغة مغذي للشعر", "صبغة سوداء خالية من الامونيا"],
        body_care: ["لوشن مرطب للجسم", "مقشر السكر المنعم للبشرة", "زيت مساج مهدئ للبشرة", "زبدة الشيا العضوية للجسم", "معطر وملمع جسم هولوغرافيك"],
        deodorants: ["مزيل عرق خالي من الألومنيوم", "رول أون تفتيح منطقة الإبط", "بخاخ حماية يدوم 48 ساعة", "كريم مزيل عرق طبيعي", "مزيل عرق للمراهقين لطيف"],
        accessories_tools: ["طقم فرش مكياج متكامل", "إسفنجة دمج المكياج مرنة", "أداة عقص الرموش", "فرشاة تنظيف الوجه سيليكون", "حقيبة مكياج شفافة"]
      };

      const categoryImageMap: Record<string, string> = {
        perfumes: "https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&w=300&q=80",
        skin_care: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=300&q=80",
        face_creams: "https://images.unsplash.com/photo-1608248597481-496100c80836?auto=format&fit=crop&w=300&q=80",
        sunscreen: "https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=300&q=80",
        lipsticks: "https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&w=300&q=80",
        makeup_pencils: "https://images.unsplash.com/photo-1597223557154-721c1cecc4b0?auto=format&fit=crop&w=300&q=80",
        mascara: "https://images.unsplash.com/photo-1512496015851-a90fb38ba796?auto=format&fit=crop&w=300&q=80",
        eyeliner: "https://images.unsplash.com/photo-1625093742435-6fa192b6fb10?auto=format&fit=crop&w=300&q=80",
        kohl: "https://images.unsplash.com/photo-1512495976007-0e4a7e557b40?auto=format&fit=crop&w=300&q=80",
        eyeshadow: "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=300&q=80",
        foundation: "https://images.unsplash.com/photo-1599733589046-9b8308b5b50d?auto=format&fit=crop&w=300&q=80",
        concealer: "https://images.unsplash.com/photo-1617897903246-719242758050?auto=format&fit=crop&w=300&q=80",
        powder: "https://images.unsplash.com/photo-1590156546746-c58d8b241353?auto=format&fit=crop&w=300&q=80",
        blusher: "https://images.unsplash.com/photo-1631730359575-38e4755d772b?auto=format&fit=crop&w=300&q=80",
        contour: "https://images.unsplash.com/photo-1512495976007-0e4a7e557b40?auto=format&fit=crop&w=300&q=80",
        highlighter: "https://images.unsplash.com/photo-1515688594390-b649af70d282?auto=format&fit=crop&w=300&q=80",
        makeup_fixer: "https://images.unsplash.com/photo-1601049541289-9b1b7bbbfe19?auto=format&fit=crop&w=300&q=80",
        primer: "https://images.unsplash.com/photo-1616683693504-3ea7e9ad6fec?auto=format&fit=crop&w=300&q=80",
        hair_care: "https://images.unsplash.com/photo-1526947425960-945c6e72858f?auto=format&fit=crop&w=300&q=80",
        shampoo_conditioner: "https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?auto=format&fit=crop&w=300&q=80",
        hair_dyes: "https://images.unsplash.com/photo-1560869713-7d0a29430f23?auto=format&fit=crop&w=300&q=80",
        body_care: "https://images.unsplash.com/photo-1556228453-efd6c1ff04f6?auto=format&fit=crop&w=300&q=80",
        deodorants: "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=300&q=80",
        accessories_tools: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=300&q=80"
      };

      const cats = categories.length > 0 ? categories : [{ id: "perfumes", name: "العطور", icon: "air" }];
      const generatedList: Product[] = [];
      const now = Date.now();

      for (let i = 1; i <= 1050; i++) {
        const cat = cats[i % cats.length];
        const templates = categoryTemplates[cat.id] || ["مستحضر تجميلي رائع", "منتج لمسة جمال مميز"];
        const baseName = templates[i % templates.length];
        const brand = brands[i % brands.length];
        const name = `${baseName} - ${brand} (تجريبي #${i})`;
        const price = 5000 + (i % 70) * 1000;
        const quantity = 10 + (i % 141);
        const lowStockThreshold = 5;
        const targetImg = categoryImageMap[cat.id] || "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=300&q=80";

        generatedList.push({
          id: `prod_mock_${i}_${now}`,
          name,
          brand,
          categoryId: cat.id,
          price,
          quantity,
          lowStockThreshold,
          image: targetImg,
          createdAt: now - i * 1000
        });
      }

      await onBulkSaveProducts(generatedList);
      setSuccessMsg("تم توليد 1050 منتجاً وتوزيعهم بنجاح!");
      setTimeout(() => setSuccessMsg(""), 4000);
    } catch (err) {
      console.error("Bulk save error:", err);
    } finally {
      setIsGenerating(false);
    }
  };

  // Switch renderer for sub-views to keep things clean and modular
  if (activeSubTab === "shifts") {
    return (
      <ShiftsAdmin
        shifts={shifts}
        sales={sales}
        activeShift={activeShift}
        onOpenShift={onOpenShift}
        onCloseShift={onCloseShift}
        onDeleteShift={onDeleteShift}
        onBack={() => onSubTabChange("general")}
      />
    );
  }

  if (activeSubTab === "history") {
    return (
      <SalesHistory
        sales={sales}
        onDeleteSale={onDeleteSale}
        onBack={() => onSubTabChange("general")}
      />
    );
  }

  if (activeSubTab === "reports") {
    return (
      <Reports
        sales={sales}
        products={products}
        productsRevision={productsRevision}
        onBack={() => onSubTabChange("general")}
      />
    );
  }

  if (activeSubTab === "customers") {
    return (
      <CustomersAdmin
        onBack={() => onSubTabChange("general")}
      />
    );
  }

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden pb-16 text-right font-sans" dir="rtl">
      {/* Header Panel */}
      <div className="p-4 bg-white border-b border-slate-100 shrink-0 flex items-center justify-between">
        {onLogout ? (
          <button
            onClick={onLogout}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-danger/20 hover:bg-danger/5 text-danger text-xs font-bold transition-all cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>تسجيل الخروج</span>
          </button>
        ) : <div />}
        <div>
          <h2 className="text-xl font-bold text-slate-800">إعدادات النظام</h2>
          <p className="text-xs text-slate-400 font-medium">إعدادات تشغيل {activeCosmeticName} وتخصيص البيانات والعمليات</p>
        </div>
      </div>

      {/* Settings Form Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6 no-scrollbar">
        {/* Toast Success Message */}
        <AnimatePresence>
          {successMsg && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-2xl p-4 text-xs font-bold flex items-center justify-end gap-2"
            >
              <span>{successMsg}</span>
              <span className="material-symbols-outlined !text-xl">check_circle</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Operations Directory */}
        <div className="bg-white border border-rose-100/10 rounded-3xl p-5 shadow-xs space-y-4">
          <h3 className="text-xs font-black text-slate-800 tracking-wide">إدارة العمليات والتقارير</h3>
          
          <div className="space-y-3">
            {/* Customer Management button - Visible only to master administrator ali */}
            {currentUser?.username === "ali" && (
              <button
                id="btn-goto-customers"
                onClick={() => onSubTabChange("customers")}
                className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-indigo-50 hover:bg-indigo-100/60 active:scale-[0.99] border border-indigo-100 hover:border-indigo-200 transition-all text-right cursor-pointer"
              >
                <span className="material-symbols-outlined text-indigo-600 !text-xl">chevron_left</span>
                <div className="flex items-center gap-3 flex-1 justify-end">
                  <div className="text-right">
                    <h4 className="text-xs font-extrabold text-indigo-600">إدارة العملاء والتراخيص السحابية</h4>
                    <p className="text-[10px] text-indigo-500/80 font-semibold mt-0.5">تفعيل حسابات المحلات وإصدار وتجديد التراخيص</p>
                  </div>
                  <div className="w-9 h-9 rounded-xl bg-indigo-500 text-white flex items-center justify-center shrink-0">
                    <span className="material-symbols-outlined !text-xl">admin_panel_settings</span>
                  </div>
                </div>
              </button>
            )}

            {/* Shifts Item */}
            <button
              id="btn-goto-shifts"
              onClick={() => onSubTabChange("shifts")}
              className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-slate-50/50 hover:bg-rose-50/40 active:scale-[0.99] border border-slate-100/50 hover:border-rose-100/30 transition-all text-right cursor-pointer"
            >
              <span className="material-symbols-outlined text-slate-400 !text-xl">chevron_left</span>
              <div className="flex items-center gap-3 flex-1 justify-end">
                <div className="text-right">
                  <h4 className="text-xs font-extrabold text-slate-800">إدارة الورديات (صندوق النقد)</h4>
                  <p className="text-[10px] text-slate-400 font-medium mt-0.5">مراقبة الفتح والإغلاق والمبالغ النقدية</p>
                </div>
                <div className="w-9 h-9 rounded-xl bg-pink-50 text-pink-600 flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined !text-xl">work_history</span>
                </div>
              </div>
            </button>

            {/* Sales History Item */}
            <button
              id="btn-goto-history"
              onClick={() => onSubTabChange("history")}
              className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-slate-50/50 hover:bg-rose-50/40 active:scale-[0.99] border border-slate-100/50 hover:border-rose-100/30 transition-all text-right cursor-pointer"
            >
              <span className="material-symbols-outlined text-slate-400 !text-xl">chevron_left</span>
              <div className="flex items-center gap-3 flex-1 justify-end">
                <div className="text-right">
                  <h4 className="text-xs font-extrabold text-slate-800">سجل المبيعات والفواتير</h4>
                  <p className="text-[10px] text-slate-400 font-medium mt-0.5">استعراض كافة الفواتير الصادرة وتعديلها</p>
                </div>
                <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined !text-xl">history</span>
                </div>
              </div>
            </button>

            {/* Reports Item */}
            <button
              id="btn-goto-reports"
              onClick={() => onSubTabChange("reports")}
              className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-slate-50/50 hover:bg-rose-50/40 active:scale-[0.99] border border-slate-100/50 hover:border-rose-100/30 transition-all text-right cursor-pointer"
            >
              <span className="material-symbols-outlined text-slate-400 !text-xl">chevron_left</span>
              <div className="flex items-center gap-3 flex-1 justify-end">
                <div className="text-right">
                  <h4 className="text-xs font-extrabold text-slate-800">التقارير والإحصائيات العامة</h4>
                  <p className="text-[10px] text-slate-400 font-medium mt-0.5">تحليل أرباح المتجر وحالة مخزون المستودع</p>
                </div>
                <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined !text-xl">analytics</span>
                </div>
              </div>
            </button>
          </div>
        </div>

        {/* Configuration settings form */}
        <form onSubmit={handleSave} className="bg-white border border-slate-100 rounded-3xl p-5 shadow-xs space-y-5 text-right">
          <h3 className="text-xs font-black text-slate-850 tracking-wide">تخصيص الإعدادات العامة</h3>

          {/* Default low stock limit */}
          <div>
            <label className="block text-xs font-bold text-slate-500 mb-1.5">الحد الافتراضي لانخفاض المخزون</label>
            <input
              id="settings-low-stock"
              type="number"
              value={defaultLowStock}
              onChange={(e) => setDefaultLowStock(Math.max(0, Number(e.target.value)))}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-rose-500 focus:ring-opacity-20 text-xs font-semibold [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none text-right text-slate-850"
            />
            <p className="text-[10px] text-slate-400 mt-1 font-medium">سيعتمد هذا الرقم تلقائياً لجميع المنتجات الجديدة المضافة مستقبلاً.</p>
          </div>

          {/* Submit */}
          <button
            id="btn-save-settings"
            type="submit"
            className="w-full py-3.5 bg-[#800F35] hover:bg-[#5C0620] active:scale-95 text-white font-bold rounded-xl shadow-md shadow-rose-100/15 transition-all text-xs flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <span className="material-symbols-outlined !text-lg">save</span>
            حفظ التغييرات
          </button>
        </form>

        {/* Manager-only Mock Product Generation Option */}
        {currentUser?.role === "manager" && (
          <div className="bg-white border border-amber-100 rounded-3xl p-5 shadow-xs space-y-4 text-right">
            <div className="flex items-center gap-2 text-amber-600 justify-end">
              <h3 className="text-xs font-black text-amber-700 tracking-wide font-sans">أدوات تجربة النظام (خاص بالمدير)</h3>
              <span className="material-symbols-outlined text-amber-600">science</span>
            </div>

            <div className="space-y-2">
              <h4 className="font-bold text-xs text-slate-700">توليد منتجات تلقائية للتجربة (أكثر من 1000 منتج)</h4>
              <p className="text-[10px] text-slate-400 leading-normal font-medium font-sans">
                يتيح لك هذا الخيار إضافة 1,050 منتجاً تجريبياً بالكامل وتوزيعها تلقائياً على تصنيفات المتجر المتوفرة مع صور مخصصة عالية الدقة لكل صنف، لتجربة كفاءة وسرعة المتجر مع الكميات الكبيرة.
              </p>
            </div>

            <button
              id="btn-generate-mock-products"
              type="button"
              disabled={isGenerating}
              onClick={handleGenerateMockProducts}
              className={`w-full py-3.5 border font-bold rounded-xl transition-all text-xs flex items-center justify-center gap-1.5 cursor-pointer ${
                isGenerating
                  ? "border-amber-200 bg-amber-50 text-amber-400 cursor-not-allowed"
                  : "border-amber-500 text-amber-700 hover:bg-amber-50 active:scale-95"
              }`}
            >
              <span className="material-symbols-outlined !text-lg">
                {isGenerating ? "hourglass_empty" : "add_to_photos"}
              </span>
              {isGenerating ? "جاري توليد 1,050 منتجاً..." : "توليد 1,050 منتجاً تجريبياً بالصور"}
            </button>
          </div>
        )}

        {/* Database Control reset */}
        <div className="bg-white border border-slate-100 rounded-3xl p-5 shadow-xs space-y-4 text-right">
          <div className="flex items-center gap-2 text-rose-500 justify-end">
            <h3 className="text-xs font-black text-rose-600 tracking-wide font-sans">المنطقة الخطرة</h3>
            <span className="material-symbols-outlined text-rose-600">gpp_maybe</span>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold text-xs text-slate-700">إعادة ضبط المتجر وبيانات المخزن</h4>
            <p className="text-[10px] text-slate-400 leading-normal font-medium font-sans">
              سيقوم هذا الإجراء بمسح كافة المبيعات المسجلة والمنتجات المعدلة والتصنيفات في قاعدة بيانات هاتفك (IndexedDB) بشكل نهائي، وإعادة تحميل البضاعة والبيانات الافتراضية المجهزة مسبقاً.
            </p>
          </div>

          <button
            id="btn-reset-db-trigger"
            type="button"
            onClick={() => setShowResetConfirm(true)}
            className="w-full py-3.5 border border-rose-200 text-rose-600 font-bold hover:bg-rose-50 active:scale-95 rounded-xl transition-all text-xs flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <span className="material-symbols-outlined !text-lg">database_off</span>
            إعادة تعيين البيانات بالكامل
          </button>
        </div>

        {/* App Info metadata */}
        <div className="bg-slate-50 border border-slate-100 rounded-3xl p-5 text-center space-y-2">
          <div className="w-10 h-10 bg-white border border-slate-100 text-rose-500 flex items-center justify-center rounded-2xl mx-auto shadow-sm">
            <span className="material-symbols-outlined !text-xl animate-pulse">spa</span>
          </div>
          <div>
            <h4 className="font-bold text-xs text-slate-700">{activeCosmeticName}</h4>
            <p className="text-[10px] text-slate-400 mt-0.5">نظام نقطة بيع POS</p>
          </div>
          <div className="pt-2 border-t border-slate-200/60 text-[9px] text-slate-400 font-mono space-y-0.5 font-bold">
            <p>الإصدار الحالي: v1.1.0 (Material 3)</p>
            <p>مطور لمصلحة {activeCosmeticName}</p>
          </div>
        </div>
      </div>

      {/* Reset Confirmation Overlay */}
      <AnimatePresence>
        {showResetConfirm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-slate-900/40 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-3xl p-6 w-full max-w-sm shadow-xl text-center space-y-4 border border-slate-100"
            >
              <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center mx-auto">
                <span className="material-symbols-outlined !text-3xl">dangerous</span>
              </div>
              <div>
                <h4 className="font-bold text-slate-800">إعادة ضبط المتجر بالكامل؟</h4>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed font-semibold">
                  هل أنت متأكد بنسبة 100%؟ سيؤدي ذلك إلى حذف سجل المبيعات بكامله ومحو بضاعتك المسجلة حالياً! لا يمكن التراجع عن هذا الإجراء نهائياً.
                </p>
              </div>
              <div className="flex gap-3 pt-2">
                <button
                  id="btn-confirm-reset-yes"
                  onClick={handleResetConfirm}
                  className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold text-xs transition-colors shadow-md cursor-pointer"
                >
                  نعم، احذف وأعد الضبط
                </button>
                <button
                  id="btn-confirm-reset-no"
                  onClick={() => setShowResetConfirm(false)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl font-bold text-xs transition-colors cursor-pointer"
                >
                  تراجع
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

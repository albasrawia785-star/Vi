/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Category, Product } from "../../types";
import { getProductCountForCategory } from "../../database/products";

interface CategoriesAdminProps {
  categories: Category[];
  products: Product[];
  onSaveCategory: (category: Category) => void;
  onDeleteCategory: (id: string, replacementCategoryId?: string) => void;
  onRestoreDefaultCategories?: () => void;
  cosmeticName?: string;
  productsRevision?: number;
}

// Available material icons for cosmetics
const MATERIAL_ICONS_LIST = [
  { value: "brush", label: "مكياج / فرشاة" },
  { value: "air", label: "عطور / هواء فواح" },
  { value: "spa", label: "بشرة / سبا" },
  { value: "content_cut", label: "شعر / مقص" },
  { value: "favorite", label: "جمال / قلب" },
  { value: "star", label: "نجمة / مميز" },
  { value: "face", label: "وجه / عناية" },
  { value: "visibility", label: "عين / ماسكارا" },
  { value: "palette", label: "ظلال / ألوان" },
  { value: "face_retouching_natural", label: "وجه طبيعي / خافي عيوب" },
  { value: "blur_on", label: "بودرة / تأثير" },
  { value: "flare", label: "إضاءة / هايلايتر" },
  { value: "clean_hands", label: "كريمات / عناية باليد" },
  { value: "wb_sunny", label: "شمس / واقي شمس" },
  { value: "water_drop", label: "قطرة ماء / شامبو" },
  { value: "color_lens", label: "ألوان / صبغة" },
  { value: "accessibility", label: "جسم / عناية بالجسم" },
  { value: "co2", label: "مزيل عرق / بخاخ" },
  { value: "shopping_bag", label: "حقيبة شراء / إكسسوارات" },
  { value: "grid_view", label: "الشبكة / الكونتور" },
  { value: "done_all", label: "تم / مثبت" },
  { value: "layers", label: "طبقات / برايمر" },
  { value: "celebration", label: "احتفال / مناسبات" },
  { value: "local_mall", label: "سوق / حقيبة تسوق" }
];

export default function CategoriesAdmin({
  categories,
  products,
  onSaveCategory,
  onDeleteCategory,
  onRestoreDefaultCategories,
  cosmeticName,
  productsRevision = 0
}: CategoriesAdminProps) {
  const [editingCat, setEditingCat] = useState<Category | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [showRestoreConfirm, setShowRestoreConfirm] = useState(false);
  const [catName, setCatName] = useState("");
  const [catIcon, setCatIcon] = useState("brush");
  const [error, setError] = useState("");

  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);
  const [replacementCatId, setReplacementCatId] = useState<string>("");
  const [productCounts, setProductCounts] = useState<{ [key: string]: number }>({});

  const alternativeCategories = useMemo(() => {
    if (!deleteTargetId) return [];
    return categories.filter((c) => c.id !== deleteTargetId);
  }, [categories, deleteTargetId]);

  React.useEffect(() => {
    if (deleteTargetId) {
      const alternatives = categories.filter((c) => c.id !== deleteTargetId);
      setReplacementCatId(alternatives[0]?.id || "");
    } else {
      setReplacementCatId("");
    }
  }, [deleteTargetId, categories]);

  const activeCosmeticName = cosmeticName || "كوزمتك لمسة جمال";

  // Count how many products are inside each category asynchronously via DB index
  React.useEffect(() => {
    let active = true;
    async function loadCounts() {
      const counts: { [key: string]: number } = {};
      for (const cat of categories) {
        try {
          counts[cat.id] = await getProductCountForCategory(cat.id);
        } catch (err) {
          counts[cat.id] = 0;
        }
      }
      if (active) {
        setProductCounts(counts);
      }
    }
    loadCounts();
    return () => {
      active = false;
    };
  }, [categories, productsRevision]);

  const handleOpenAdd = () => {
    setEditingCat(null);
    setCatName("");
    setCatIcon("brush");
    setError("");
    setShowModal(true);
  };

  const handleOpenEdit = (cat: Category) => {
    setEditingCat(cat);
    setCatName(cat.name);
    setCatIcon(cat.icon);
    setError("");
    setShowModal(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!catName.trim()) {
      setError("اسم التصنيف مطلوب");
      return;
    }

    const savedCat: Category = {
      id: editingCat?.id || `cat_${Date.now()}`,
      name: catName.trim(),
      icon: catIcon,
      createdAt: editingCat?.createdAt || Date.now()
    };

    onSaveCategory(savedCat);
    setShowModal(false);
  };

  const handleDeleteTrigger = (catId: string) => {
    setDeleteTargetId(catId);
  };

  const handleDeleteConfirm = () => {
    if (deleteTargetId) {
      const hasProducts = (productCounts[deleteTargetId] || 0) > 0;
      onDeleteCategory(deleteTargetId, hasProducts ? (replacementCatId || undefined) : undefined);
      setDeleteTargetId(null);
    }
  };

  const productsInTargetDelete = useMemo(() => {
    if (!deleteTargetId) return 0;
    return productCounts[deleteTargetId] || 0;
  }, [deleteTargetId, productCounts]);

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden pb-16 text-right" dir="rtl">
      {/* Header Panel */}
      <div className="p-4 bg-white border-b border-slate-100 flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-800">إدارة التصنيفات</h2>
          <p className="text-xs text-slate-400 font-medium">تصنيفات متجر {activeCosmeticName}</p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {onRestoreDefaultCategories && (
            <button
              id="btn-restore-default-categories"
              type="button"
              onClick={() => setShowRestoreConfirm(true)}
              className="flex items-center gap-1 px-3 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-2xl font-bold text-xs transition-all active:scale-95 cursor-pointer border border-slate-200"
              title="استعادة الـ 25 تصنيفاً الافتراضية للكوزمتك"
            >
              <span className="material-symbols-outlined !text-lg">settings_backup_restore</span>
              <span>استعادة الافتراضي</span>
            </button>
          )}

          <button
            id="btn-add-category"
            onClick={handleOpenAdd}
            className="flex items-center gap-1 px-4 py-2.5 bg-rose-500 hover:bg-rose-600 text-white rounded-2xl font-bold text-xs shadow-md shadow-rose-200 transition-all active:scale-95 cursor-pointer"
          >
            <span className="material-symbols-outlined !text-lg">add_circle</span>
            إضافة تصنيف
          </button>
        </div>
      </div>

      {/* Grid Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
        {categories.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <span className="material-symbols-outlined text-slate-300 !text-6xl mb-2">category</span>
            <p className="text-sm font-bold text-slate-600">لا توجد تصنيفات</p>
            <p className="text-xs text-slate-400 mt-1 max-w-xs leading-relaxed">
              اضغط على "إضافة تصنيف" في الأعلى لإنشاء فئة جديدة لترتيب منتجاتك.
            </p>
            {onRestoreDefaultCategories && (
              <button
                id="btn-empty-restore-default"
                type="button"
                onClick={() => setShowRestoreConfirm(true)}
                className="mt-5 flex items-center gap-1 px-4 py-2.5 bg-[#7B0F3A]/5 hover:bg-[#7B0F3A]/10 text-[#7B0F3A] border border-[#7B0F3A]/20 rounded-2xl font-extrabold text-xs transition-all active:scale-95 cursor-pointer"
              >
                <span className="material-symbols-outlined !text-lg">settings_backup_restore</span>
                <span>استعادة التصنيفات الافتراضية للـ كوزمتك</span>
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {categories.map((cat) => {
              const count = productCounts[cat.id] || 0;
              return (
                <div
                  key={cat.id}
                  id={`cat-card-${cat.id}`}
                  className="bg-white rounded-2xl border border-slate-100 shadow-xs p-4 flex items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-rose-50 text-rose-500 flex items-center justify-center">
                      <span className="material-symbols-outlined !text-2xl">{cat.icon || "category"}</span>
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-slate-800">{cat.name}</h3>
                      <p className="text-xs text-slate-400 font-semibold mt-0.5">{count} منتج مرتب تحتها</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      id={`btn-edit-cat-${cat.id}`}
                      onClick={() => handleOpenEdit(cat)}
                      className="w-9 h-9 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
                      title="تعديل التصنيف"
                    >
                      <span className="material-symbols-outlined !text-lg">edit</span>
                    </button>
                    <button
                      id={`btn-delete-cat-${cat.id}`}
                      onClick={() => handleDeleteTrigger(cat.id)}
                      className="w-9 h-9 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-500 flex items-center justify-center transition-colors cursor-pointer"
                      title="حذف التصنيف"
                    >
                      <span className="material-symbols-outlined !text-lg">delete</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Add/Edit Modal */}
      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-900/40 backdrop-blur-sm">
            <div className="absolute inset-0" onClick={() => setShowModal(false)}></div>
            <motion.div
              initial={{ opacity: 0, y: 100 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 100 }}
              className="bg-white w-full sm:max-w-md rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col p-6 z-10 space-y-4"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-rose-500 !text-2xl">
                    {editingCat ? "edit" : "add_circle"}
                  </span>
                  <h3 className="font-bold text-slate-800 text-base">
                    {editingCat ? "تعديل التصنيف" : "إضافة تصنيف جديد"}
                  </h3>
                </div>
                <button
                  onClick={() => setShowModal(false)}
                  className="w-8 h-8 rounded-full bg-slate-50 hover:bg-slate-100 flex items-center justify-center text-slate-500 transition-colors cursor-pointer"
                >
                  <span className="material-symbols-outlined">close</span>
                </button>
              </div>

              <form onSubmit={handleSave} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1.5">اسم التصنيف <span className="text-rose-500">*</span></label>
                  <input
                    id="form-cat-name"
                    type="text"
                    value={catName}
                    onChange={(e) => setCatName(e.target.value)}
                    placeholder="مثال: مستحضرات تجميل"
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-rose-500 focus:ring-opacity-20 text-sm text-right"
                  />
                  {error && <p className="text-rose-500 text-xs mt-1 font-semibold">{error}</p>}
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-2">أيقونة التصنيف المعبرة</label>
                  <div className="grid grid-cols-5 gap-2 max-h-36 overflow-y-auto p-1 border border-slate-100 rounded-xl no-scrollbar">
                    {MATERIAL_ICONS_LIST.map((ico) => (
                      <button
                        key={ico.value}
                        type="button"
                        onClick={() => setCatIcon(ico.value)}
                        className={`p-2.5 rounded-xl flex items-center justify-center transition-all cursor-pointer ${
                          catIcon === ico.value
                            ? "bg-rose-500 text-white shadow-md shadow-rose-100"
                            : "bg-slate-50 hover:bg-slate-100 text-slate-500"
                        }`}
                        title={ico.label}
                      >
                        <span className="material-symbols-outlined !text-xl">{ico.value}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex gap-3 pt-3">
                  <button
                    id="btn-cat-submit"
                    type="submit"
                    className="flex-1 py-3 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-xl shadow-md shadow-rose-100 transition-all text-sm cursor-pointer"
                  >
                    حفظ
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowModal(false)}
                    className="flex-1 py-3 border border-slate-200 text-slate-600 rounded-xl font-bold transition-all text-sm hover:bg-slate-50 cursor-pointer"
                  >
                    إلغاء
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal (Prevent deleting with warning if containing products) */}
      <AnimatePresence>
        {deleteTargetId && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-slate-900/40 backdrop-blur-xs" dir="rtl">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-xl text-center space-y-4 border border-slate-100"
            >
              <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center mx-auto">
                <span className="material-symbols-outlined !text-3xl">warning_amber</span>
              </div>
              
              <div>
                <h4 className="font-bold text-slate-800">حذف التصنيف نهائياً؟</h4>
                
                {productsInTargetDelete > 0 ? (
                  <div className="mt-2 text-right space-y-3">
                    <div className="p-3 bg-amber-50/70 rounded-xl border border-amber-200 space-y-1">
                      <p className="text-xs font-bold text-amber-800">
                        تنبيه هام جداً:
                      </p>
                      <p className="text-[11px] text-slate-600 leading-relaxed font-semibold">
                        هذا التصنيف مرتبط بـ <span className="font-bold text-rose-600">{productsInTargetDelete} من المنتجات</span>. لحماية المنتجات من فقدان تصنيفها، يرجى اختيار تصنيف بديل لنقلها إليه قبل الحذف.
                      </p>
                    </div>

                    {alternativeCategories.length > 0 ? (
                      <div className="space-y-1.5">
                        <label className="block text-xs font-bold text-slate-500">التصنيف البديل لنقل المنتجات إليه <span className="text-rose-500">*</span></label>
                        <select
                          id="form-delete-replacement-cat"
                          value={replacementCatId}
                          onChange={(e) => setReplacementCatId(e.target.value)}
                          className="w-full px-3 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-rose-500 focus:ring-opacity-20 text-xs bg-white font-semibold text-slate-700 text-right"
                        >
                          <option value="">-- اختر التصنيف البديل --</option>
                          {alternativeCategories.map((cat) => (
                            <option key={cat.id} value={cat.id}>
                              {cat.name}
                            </option>
                          ))}
                        </select>
                      </div>
                    ) : (
                      <div className="p-3 bg-rose-50 rounded-xl border border-rose-100">
                        <p className="text-[11px] text-rose-600 leading-relaxed font-bold">
                          لا يوجد أي تصنيف آخر في النظام حالياً! يرجى إنشاء تصنيف جديد أولاً في صفحة التصنيفات لتتمكن من ترحيل المنتجات إليه قبل حذف هذا التصنيف.
                        </p>
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed font-semibold font-sans">
                    هل أنت متأكد من رغبتك في حذف هذا التصنيف بالكامل؟ لا يوجد مبيعات أو منتجات متأثرة به.
                  </p>
                )}
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  id="btn-confirm-delete-cat-yes"
                  onClick={handleDeleteConfirm}
                  disabled={productsInTargetDelete > 0 && (!replacementCatId || alternativeCategories.length === 0)}
                  className={`flex-1 py-2.5 text-white rounded-xl font-bold text-xs transition-all shadow-md cursor-pointer flex items-center justify-center gap-1 ${
                    productsInTargetDelete > 0 && (!replacementCatId || alternativeCategories.length === 0)
                      ? "bg-slate-300 shadow-none cursor-not-allowed text-slate-400"
                      : "bg-rose-500 hover:bg-rose-600"
                  }`}
                >
                  {productsInTargetDelete > 0 ? "نقل المنتجات وحذف" : "نعم، احذف الفئة"}
                </button>
                <button
                  id="btn-confirm-delete-cat-no"
                  onClick={() => setDeleteTargetId(null)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl font-bold text-xs transition-colors cursor-pointer"
                >
                  تراجع
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Restore Default Categories Confirmation Modal */}
      <AnimatePresence>
        {showRestoreConfirm && onRestoreDefaultCategories && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-slate-900/40 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-xl text-center space-y-4 border border-slate-100"
            >
              <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center mx-auto">
                <span className="material-symbols-outlined !text-3xl">settings_backup_restore</span>
              </div>
              
              <div>
                <h4 className="font-bold text-slate-800">استعادة التصنيفات الافتراضية؟</h4>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed font-semibold font-sans">
                  سيقوم النظام بإضافة الـ 25 تصنيفاً الافتراضياً لمستحضرات التجميل والعطور (دون تكرار الموجود منها حالياً). هل أنت متأكد؟
                </p>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  id="btn-confirm-restore-defaults-yes"
                  onClick={() => {
                    onRestoreDefaultCategories();
                    setShowRestoreConfirm(false);
                  }}
                  className="flex-1 py-2.5 bg-rose-500 hover:bg-rose-600 text-white rounded-xl font-bold text-xs transition-colors shadow-md cursor-pointer"
                >
                  نعم، استعد التصنيفات
                </button>
                <button
                  id="btn-confirm-restore-defaults-no"
                  onClick={() => setShowRestoreConfirm(false)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl font-bold text-xs transition-colors cursor-pointer"
                >
                  تراجع
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

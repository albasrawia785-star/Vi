/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useMemo, useState, useEffect } from "react";
import { Product, SaleTransaction } from "../types";
import { APP_CONFIG } from "../config";
import { getLowStockProducts, getTotalProductsCount } from "../database/products";

interface ReportsProps {
  sales: SaleTransaction[];
  products: Product[];
  onBack?: () => void;
  productsRevision?: number;
}

export default function Reports({ sales, products, onBack, productsRevision = 0 }: ReportsProps) {
  const [lowStockProducts, setLowStockProducts] = useState<Product[]>([]);
  const [totalProductsCount, setTotalProductsCount] = useState(0);

  useEffect(() => {
    let active = true;
    async function loadStats() {
      try {
        const list = await getLowStockProducts(100);
        const total = await getTotalProductsCount();
        if (active) {
          setLowStockProducts(list);
          setTotalProductsCount(total);
        }
      } catch (err) {
        console.error("Failed to load product stats in Reports:", err);
      }
    }
    loadStats();
    return () => {
      active = false;
    };
  }, [productsRevision]);

  const formatPrice = (price: number) => {
    return price.toLocaleString("en-US") + " " + APP_CONFIG.currency;
  };

  // Timestamps / boundaries
  const now = new Date();
  
  const startOfToday = useMemo(() => {
    const today = new Date(now);
    today.setHours(0, 0, 0, 0);
    return today.getTime();
  }, [now]);

  const startOfThisMonth = useMemo(() => {
    const month = new Date(now.getFullYear(), now.getMonth(), 1);
    return month.getTime();
  }, [now]);

  // Calculated Metrics
  const stats = useMemo(() => {
    let total = 0;
    let daily = 0;
    let monthly = 0;
    const transactionsCount = sales.length;

    sales.forEach((sale) => {
      total += sale.totalAmount;
      if (sale.timestamp >= startOfToday) {
        daily += sale.totalAmount;
      }
      if (sale.timestamp >= startOfThisMonth) {
        monthly += sale.totalAmount;
      }
    });

    return { total, daily, monthly, transactionsCount };
  }, [sales, startOfToday, startOfThisMonth]);

  // Aggregate Sold Products (Top sold items with total quantities)
  const soldProductsAggregated = useMemo(() => {
    const agg: { [key: string]: { name: string; brand: string; qty: number; totalRev: number } } = {};

    sales.forEach((sale) => {
      sale.items.forEach((item) => {
        if (!agg[item.productId]) {
          agg[item.productId] = {
            name: item.name,
            brand: item.brand,
            qty: 0,
            totalRev: 0
          };
        }
        agg[item.productId].qty += item.quantity;
        agg[item.productId].totalRev += item.total;
      });
    });

    // Convert to sorted array by quantity sold descending
    return Object.values(agg).sort((a, b) => b.qty - a.qty);
  }, [sales]);

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden pb-16">
      {/* Header Panel */}
      <div className="p-4 bg-white border-b border-slate-100 shrink-0">
        <div className="flex items-center gap-3">
          {onBack && (
            <button
              onClick={onBack}
              type="button"
              className="w-10 h-10 rounded-full bg-rose-50 hover:bg-rose-100 active:scale-95 text-[#800F35] flex items-center justify-center transition-all cursor-pointer border border-rose-100/30"
              title="رجوع"
            >
              <span className="material-symbols-outlined font-black">arrow_forward</span>
            </button>
          )}
          <div className="flex-1 text-right">
            <h2 className="text-xl font-bold text-slate-800">تقارير المبيعات والمستودع</h2>
            <p className="text-xs text-slate-400 font-medium">مستويات الأداء اليومي والشهري وحالة المخازن</p>
          </div>
        </div>
      </div>

      {/* Reports content container */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6 no-scrollbar">
        
        {/* Core Metrics Grid */}
        <div className="grid grid-cols-2 gap-3">
          
          {/* Total Sales Card */}
          <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-xs space-y-1.5 flex flex-col justify-between">
            <div className="flex items-center gap-1.5 text-rose-500">
              <span className="material-symbols-outlined !text-lg">paid</span>
              <span className="text-[10px] font-bold text-slate-400">إجمالي المبيعات</span>
            </div>
            <p className="text-sm font-black text-slate-800 truncate font-mono">
              {formatPrice(stats.total)}
            </p>
          </div>

          {/* Daily Sales Card */}
          <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-xs space-y-1.5 flex flex-col justify-between">
            <div className="flex items-center gap-1.5 text-blue-500">
              <span className="material-symbols-outlined !text-lg">today</span>
              <span className="text-[10px] font-bold text-slate-400">مبيعات اليوم</span>
            </div>
            <p className="text-sm font-black text-slate-800 truncate font-mono">
              {formatPrice(stats.daily)}
            </p>
          </div>

          {/* Monthly Sales Card */}
          <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-xs space-y-1.5 flex flex-col justify-between">
            <div className="flex items-center gap-1.5 text-purple-500">
              <span className="material-symbols-outlined !text-lg">calendar_month</span>
              <span className="text-[10px] font-bold text-slate-400">مبيعات الشهر</span>
            </div>
            <p className="text-sm font-black text-slate-800 truncate font-mono">
              {formatPrice(stats.monthly)}
            </p>
          </div>

          {/* Transactions Count Card */}
          <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-xs space-y-1.5 flex flex-col justify-between">
            <div className="flex items-center gap-1.5 text-emerald-500">
              <span className="material-symbols-outlined !text-lg">receipt</span>
              <span className="text-[10px] font-bold text-slate-400">عمليات البيع</span>
            </div>
            <p className="text-sm font-black text-slate-800 truncate font-mono">
              {stats.transactionsCount} فواتير
            </p>
          </div>

          {/* Total Products Card */}
          <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-xs space-y-1.5 flex flex-col justify-between">
            <div className="flex items-center gap-1.5 text-amber-500">
              <span className="material-symbols-outlined !text-lg">inventory_2</span>
              <span className="text-[10px] font-bold text-slate-400">عدد المنتجات الكلي</span>
            </div>
            <p className="text-sm font-black text-slate-800 truncate font-mono">
              {totalProductsCount} صنف
            </p>
          </div>

          {/* Low Stock Products Card */}
          <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-xs space-y-1.5 flex flex-col justify-between">
            <div className="flex items-center gap-1.5 text-rose-500">
              <span className="material-symbols-outlined !text-lg">error_outline</span>
              <span className="text-[10px] font-bold text-slate-400">قليلة المخزون</span>
            </div>
            <p className="text-sm font-black text-slate-800 truncate font-mono">
              {lowStockProducts.length} منتجات
            </p>
          </div>

        </div>

        {/* Aggregate Sold Products List */}
        <div className="space-y-2.5">
          <div className="flex justify-between items-center px-1">
            <h3 className="text-xs font-bold text-slate-400 tracking-wider">المنتجات الأكثر مبيعاً</h3>
            <span className="text-[10px] font-bold text-rose-500 bg-rose-50 px-2 py-0.5 rounded-full">
              {soldProductsAggregated.length} صنف مباع
            </span>
          </div>

          <div className="bg-white border border-slate-100 rounded-2xl overflow-hidden divide-y divide-slate-100 shadow-xs">
            {soldProductsAggregated.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400 font-semibold leading-relaxed">
                لم يتم بيع أي منتجات حتى الآن لتجميع إحصائيات المبيعات.
              </div>
            ) : (
              soldProductsAggregated.map((prod, idx) => (
                <div key={idx} className="p-3.5 flex items-center justify-between gap-4 text-xs">
                  <div className="min-w-0 flex-1">
                    <p className="font-bold text-slate-800 truncate">{prod.name}</p>
                    <p className="text-[10px] text-slate-400 font-semibold mt-0.5">{prod.brand}</p>
                  </div>

                  <div className="text-left shrink-0 font-mono">
                    <p className="font-bold text-slate-800">{prod.qty} قطع</p>
                    <p className="text-[10px] text-rose-500 font-extrabold mt-0.5">
                      {formatPrice(prod.totalRev)}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Low Stock Warning List */}
        <div className="space-y-2.5">
          <div className="flex justify-between items-center px-1">
            <h3 className="text-xs font-bold text-slate-400 tracking-wider">تنبيهات انخفاض المخزون</h3>
            <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
              lowStockProducts.length > 0 ? "bg-rose-50 text-rose-500 animate-pulse" : "bg-slate-100 text-slate-500"
            }`}>
              {lowStockProducts.length} منتجات منخفضة
            </span>
          </div>

          <div className="bg-white border border-slate-100 rounded-2xl overflow-hidden divide-y divide-slate-100 shadow-xs">
            {lowStockProducts.length === 0 ? (
              <div className="p-8 text-center text-xs text-emerald-600 bg-emerald-50/20 font-bold flex flex-col items-center gap-1.5">
                <span className="material-symbols-outlined !text-2xl text-emerald-500">check_circle</span>
                جميع مستويات المخازن آمنة وكافية!
              </div>
            ) : (
              lowStockProducts.map((prod) => (
                <div key={prod.id} className="p-3.5 flex items-center justify-between gap-4 text-xs">
                  <div>
                    <p className="font-bold text-slate-800 truncate">{prod.name}</p>
                    <p className="text-[10px] text-slate-400 font-semibold mt-0.5">{prod.brand}</p>
                  </div>

                  <div className="text-left shrink-0">
                    <p className={`font-black font-mono ${prod.quantity === 0 ? "text-rose-600 animate-pulse" : "text-amber-500"}`}>
                      {prod.quantity === 0 ? "نافد تماماً" : `${prod.quantity} قطع متبقية`}
                    </p>
                    <p className="text-[9px] text-slate-400 font-semibold mt-0.5">
                      (الحد الأدنى: {prod.lowStockThreshold})
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

      </div>
    </div>
  );
}

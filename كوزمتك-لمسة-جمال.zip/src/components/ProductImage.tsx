/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

interface ProductImageProps {
  image?: string;
  categoryId: string;
  name: string;
  className?: string;
}

export default function ProductImage({ image, categoryId, name, className = "" }: ProductImageProps) {
  // Use custom image if uploaded/defined
  if (image && image.trim() !== "") {
    return (
      <img
        src={image}
        alt={name}
        className={`w-full h-full object-cover select-none ${className}`}
        referrerPolicy="no-referrer"
        loading="lazy"
      />
    );
  }

  const lowercaseName = name.toLowerCase();
  let imgUrl = "";

  // 1. Direct Category ID Map (matching the 24 new default categories)
  const categoryImageMap: Record<string, string> = {
    perfumes: "https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&w=300&q=80", // Luxury perfume bottle
    skin_care: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=300&q=80", // Dropper serum bottle
    face_creams: "https://images.unsplash.com/photo-1608248597481-496100c80836?auto=format&fit=crop&w=300&q=80", // Cream white jar
    sunscreen: "https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=300&q=80", // Sunscreen bottle
    lipsticks: "https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&w=300&q=80", // Red lipstick
    makeup_pencils: "https://images.unsplash.com/photo-1597223557154-721c1cecc4b0?auto=format&fit=crop&w=300&q=80", // Cosmetic pencils
    mascara: "https://images.unsplash.com/photo-1512496015851-a90fb38ba796?auto=format&fit=crop&w=300&q=80", // Mascara brush and tubes
    eyeliner: "https://images.unsplash.com/photo-1625093742435-6fa192b6fb10?auto=format&fit=crop&w=300&q=80", // Eyeliner stroke or application
    kohl: "https://images.unsplash.com/photo-1512495976007-0e4a7e557b40?auto=format&fit=crop&w=300&q=80", // Eyeliner kohl
    eyeshadow: "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=300&q=80", // Eyeshadow color palette
    foundation: "https://images.unsplash.com/photo-1599733589046-9b8308b5b50d?auto=format&fit=crop&w=300&q=80", // Face foundation
    concealer: "https://images.unsplash.com/photo-1617897903246-719242758050?auto=format&fit=crop&w=300&q=80", // Concealer bottle
    powder: "https://images.unsplash.com/photo-1590156546746-c58d8b241353?auto=format&fit=crop&w=300&q=80", // Powder case and brush
    blusher: "https://images.unsplash.com/photo-1631730359575-38e4755d772b?auto=format&fit=crop&w=300&q=80", // Blusher pink shade
    contour: "https://images.unsplash.com/photo-1512495976007-0e4a7e557b40?auto=format&fit=crop&w=300&q=80", // Contour palette
    highlighter: "https://images.unsplash.com/photo-1515688594390-b649af70d282?auto=format&fit=crop&w=300&q=80", // Glow highlighter makeup
    makeup_fixer: "https://images.unsplash.com/photo-1601049541289-9b1b7bbbfe19?auto=format&fit=crop&w=300&q=80", // Setting spray
    primer: "https://images.unsplash.com/photo-1616683693504-3ea7e9ad6fec?auto=format&fit=crop&w=300&q=80", // Base tube primer
    hair_care: "https://images.unsplash.com/photo-1526947425960-945c6e72858f?auto=format&fit=crop&w=300&q=80", // Organic hair oil
    shampoo_conditioner: "https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?auto=format&fit=crop&w=300&q=80", // Shampoo bottles
    hair_dyes: "https://images.unsplash.com/photo-1560869713-7d0a29430f23?auto=format&fit=crop&w=300&q=80", // Hair coloring brush
    body_care: "https://images.unsplash.com/photo-1556228453-efd6c1ff04f6?auto=format&fit=crop&w=300&q=80", // Soap, oil & body care set
    deodorants: "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=300&q=80", // Spray and fresh roll-on style
    accessories_tools: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=300&q=80" // Cosmetic brushes and mirrors
  };

  if (categoryImageMap[categoryId]) {
    imgUrl = categoryImageMap[categoryId];
  } else {
    // 2. Legacy / Substring-based mapping for robust fallbacks
    if (categoryId === "makeup" || categoryId === "makeup_pencils" || categoryId === "lipsticks") {
      if (lowercaseName.includes("حمرة") || lowercaseName.includes("شفاه") || lowercaseName.includes("lip")) {
        imgUrl = "https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&w=300&q=80";
      } else if (lowercaseName.includes("ماسكارا") || lowercaseName.includes("رموش") || lowercaseName.includes("mascara")) {
        imgUrl = "https://images.unsplash.com/photo-1512496015851-a90fb38ba796?auto=format&fit=crop&w=300&q=80";
      } else if (lowercaseName.includes("أساس") || lowercaseName.includes("كريم") || lowercaseName.includes("foundation")) {
        imgUrl = "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=300&q=80";
      } else {
        imgUrl = "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=300&q=80";
      }
    } else if (categoryId === "perfume" || categoryId === "perfumes") {
      if (lowercaseName.includes("شانيل") || lowercaseName.includes("بلو") || lowercaseName.includes("chanel")) {
        imgUrl = "https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=300&q=80";
      } else {
        imgUrl = "https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&w=300&q=80";
      }
    } else if (categoryId === "skincare" || categoryId === "skin_care" || categoryId === "face_creams") {
      if (lowercaseName.includes("سيروم") || lowercaseName.includes("هيالورونيك") || lowercaseName.includes("serum")) {
        imgUrl = "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=300&q=80";
      } else {
        imgUrl = "https://images.unsplash.com/photo-1608248597481-496100c80836?auto=format&fit=crop&w=300&q=80";
      }
    } else if (categoryId === "haircare" || categoryId === "hair_care" || categoryId === "shampoo_conditioner") {
      if (lowercaseName.includes("ميلي") || lowercaseName.includes("زيت") || lowercaseName.includes("oil")) {
        imgUrl = "https://images.unsplash.com/photo-1526947425960-945c6e72858f?auto=format&fit=crop&w=300&q=80";
      } else {
        imgUrl = "https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?auto=format&fit=crop&w=300&q=80";
      }
    } else {
      if (lowercaseName.includes("عطر") || lowercaseName.includes("perfume") || lowercaseName.includes("spray")) {
        imgUrl = "https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&w=300&q=80";
      } else if (lowercaseName.includes("شعر") || lowercaseName.includes("hair") || lowercaseName.includes("شامبو")) {
        imgUrl = "https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?auto=format&fit=crop&w=300&q=80";
      } else if (lowercaseName.includes("وجه") || lowercaseName.includes("بشرة") || lowercaseName.includes("skin") || lowercaseName.includes("cream")) {
        imgUrl = "https://images.unsplash.com/photo-1608248597481-496100c80836?auto=format&fit=crop&w=300&q=80";
      } else {
        imgUrl = "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=300&q=80";
      }
    }
  }

  return (
    <img
      src={imgUrl}
      alt={name}
      className={`w-full h-full object-cover select-none ${className}`}
      referrerPolicy="no-referrer"
      loading="lazy"
    />
  );
}

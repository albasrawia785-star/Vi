/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent } from "react";
import { motion, AnimatePresence } from "motion/react";
import { POSShift, SaleTransaction } from "../types";
import { APP_CONFIG } from "../config";

interface ShiftsAdminProps {
  shifts: POSShift[];
  sales: SaleTransaction[];
  activeShift: POSShift | null;
  onOpenShift: (startBalance: number) => Promise<void>;
  onCloseShift: (endBalance: number) => Promise<void>;
  onDeleteShift?: (id: string) => Promise<void>;
  onBack?: () => void;
}

export default function ShiftsAdmin({
  shifts,
  sales,
  activeShift,
  onOpenShift,
  onCloseShift,
  onDeleteShift,
  onBack
}: ShiftsAdminProps) {
  const [startBalanceInput, setStartBalanceInput] = useState<number | "">("");
  const [endBalanceInput, setEndBalanceInput] = useState<number | "">("");
  const [showOpenConfirm, setShowOpenConfirm] = useState(false);
  const [showCloseConfirm, setShowCloseConfirm] = useState(false);
  const [expandedShiftId, setExpandedShiftId] = useState<string | null>(null);
  const [selectedSale, setSelectedSale] = useState<SaleTransaction | null>(null);
  const [shiftToDelete, setShiftToDelete] = useState<POSShift | null>(null);

  // Helper formatting functions
  const formatPrice = (price: number) => {
    return price.toLocaleString("en-US") + " " + APP_CONFIG.currency;
  };

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleString("ar-IQ", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      hour12: true
    });
  };

  const formatOnlyDate = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString("ar-IQ", {
      year: "numeric",
      month: "long",
      day: "numeric"
    });
  };

  // Filter sales belonging to a specific shift
  const getSalesForShift = (shiftId: string) => {
    return sales.filter((sale) => sale.shiftId === shiftId);
  };

  // Calculate current real-time stats of active shift
  const activeShiftSales = activeShift ? getSalesForShift(activeShift.id) : [];
  const activeShiftSalesCount = activeShiftSales.length;
  const activeShiftSalesTotal = activeShiftSales.reduce((sum, s) => sum + s.totalAmount, 0);
  const expectedEndBalance = activeShift ? (activeShift.startBalance + activeShiftSalesTotal) : 0;

  const handleOpenShiftSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const balance = startBalanceInput === "" ? 0 : Number(startBalanceInput);
    await onOpenShift(balance);
    setStartBalanceInput("");
    setShowOpenConfirm(false);
  };

  const handleCloseShiftSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const balance = endBalanceInput === "" ? expectedEndBalance : Number(endBalanceInput);
    await onCloseShift(balance);
    setEndBalanceInput("");
    setShowCloseConfirm(false);
  };

  const toggleExpandShift = (shiftId: string) => {
    setExpandedShiftId((prev) => (prev === shiftId ? null : shiftId));
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden pb-16">
      {/* Header */}
      <div className="p-4 bg-white border-b border-slate-100 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {onBack && (
            <button
              onClick={onBack}
              type="button"
              className="w-10 h-10 rounded-full bg-rose-50 hover:bg-rose-100 active:scale-95 text-[#800F35] flex items-center justify-center transition-all cursor-pointer border border-rose-100/30"
              title="رجوع"
            >
              <span className="material-symbols-outlined font-black">arrow_forward</span>
            </button>
          )}
          <div className="text-right">
            <h2 className="text-xl font-bold text-slate-800">إدارة ورديات نقطة البيع</h2>
            <p className="text-xs text-slate-400 font-medium">افتح وأغلق الورديات لمتابعة حركة المبيعات النقدية</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {activeShift ? (
            <span className="flex items-center gap-1 text-[10px] font-black bg-emerald-50 text-emerald-600 px-2.5 py-1 rounded-full border border-emerald-100">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              الوردية مفتوحة
            </span>
          ) : (
            <span className="flex items-center gap-1 text-[10px] font-black bg-slate-100 text-slate-500 px-2.5 py-1 rounded-full border border-slate-200">
              <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
              الوردية مغلقة
            </span>
          )}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
        {/* CURRENT ACTIVE SHIFT STATUS */}
        {activeShift ? (
          <div className="bg-gradient-to-br from-rose-50 to-rose-100/60 rounded-[28px] border border-rose-100 p-5 space-y-4 shadow-sm">
            <div className="flex justify-between items-start">
              <div className="space-y-1 text-right">
                <span className="text-[9px] font-black text-rose-500 uppercase tracking-widest block">الوردية الحالية النشطة</span>
                <p className="text-xs font-bold text-slate-700">تاريخ البدء: {formatDate(activeShift.startTime)}</p>
              </div>
              <div className="w-10 h-10 bg-rose-500 text-white rounded-2xl flex items-center justify-center shadow-md shadow-rose-200">
                <span className="material-symbols-outlined">schedule</span>
              </div>
            </div>

            {/* Live Stats Grid */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <div className="bg-white/80 rounded-2xl p-3 border border-rose-100/50 text-right">
                <span className="text-[10px] text-slate-400 font-bold block">رصيد صندوق البداية</span>
                <span className="text-sm font-black text-slate-700 font-mono tracking-tight">
                  {formatPrice(activeShift.startBalance)}
                </span>
              </div>
              <div className="bg-white/80 rounded-2xl p-3 border border-rose-100/50 text-right">
                <span className="text-[10px] text-slate-400 font-bold block">مبيعات الوردية النقدية</span>
                <span className="text-sm font-black text-rose-600 font-mono tracking-tight">
                  {formatPrice(activeShiftSalesTotal)}
                </span>
              </div>
              <div className="bg-white/80 rounded-2xl p-3 border border-rose-100/50 text-right">
                <span className="text-[10px] text-slate-400 font-bold block">عدد الفواتير الصادرة</span>
                <span className="text-sm font-black text-slate-700 font-mono tracking-tight">
                  {activeShiftSalesCount} فاتورة
                </span>
              </div>
              <div className="bg-white/80 rounded-2xl p-3 border border-rose-100/50 text-right">
                <span className="text-[10px] text-slate-400 font-bold block">الرصيد المتوقع بالصندوق</span>
                <span className="text-sm font-black text-rose-600 font-mono tracking-tight">
                  {formatPrice(expectedEndBalance)}
                </span>
              </div>
            </div>

            {/* Close Shift Trigger Button */}
            <button
              onClick={() => {
                setEndBalanceInput(expectedEndBalance);
                setShowCloseConfirm(true);
              }}
              className="w-full py-3.5 bg-rose-500 hover:bg-rose-600 active:scale-95 text-white font-bold rounded-2xl text-xs transition-all shadow-md shadow-rose-200 flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span className="material-symbols-outlined !text-base">logout</span>
              إغلاق نقطة البيع وتسليم الصندوق
            </button>
          </div>
        ) : (
          /* CLOSED STATUS / OPEN NEW SHIFT FORM TRIGGER */
          <div className="bg-white rounded-[28px] border border-slate-100 p-6 text-center space-y-4 shadow-xs">
            <div className="w-16 h-16 bg-slate-50 text-slate-400 flex items-center justify-center rounded-3xl mx-auto border border-slate-100/50">
              <span className="material-symbols-outlined !text-3xl">lock</span>
            </div>
            <div className="space-y-1.5 max-w-xs mx-auto">
              <h3 className="font-extrabold text-slate-800 text-base">نقطة البيع مغلقة حالياً</h3>
              <p className="text-xs text-slate-400 leading-relaxed font-semibold">
                يجب فتح نقطة بيع (وردية جديدة) وتحديد رصيد الصندوق لكي تتمكن من إدراج المبيعات وتصدر فواتير جديدة للزبائن.
              </p>
            </div>
            <button
              onClick={() => setShowOpenConfirm(true)}
              className="w-full py-3.5 bg-rose-500 hover:bg-rose-600 active:scale-95 text-white font-bold rounded-2xl text-xs transition-all shadow-md shadow-rose-200 flex items-center justify-center gap-1.5 cursor-pointer max-w-sm mx-auto"
            >
              <span className="material-symbols-outlined !text-base">key</span>
              فتح نقطة بيع جديدة للبدء بالعمل
            </button>
          </div>
        )}

        {/* HISTORIC SHIFTS LOG */}
        <div className="space-y-3 pt-2">
          <h3 className="text-xs font-bold text-slate-400 text-right pr-1">سجل الورديات السابقة ونقاط البيع</h3>

          {shifts.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-100/80 p-8 text-center text-slate-400">
              <span className="material-symbols-outlined !text-4xl mb-1 text-slate-300">work_history</span>
              <p className="text-xs font-bold">لا يوجد تاريخ ورديات مسجلة سابقاً</p>
            </div>
          ) : (
            shifts.map((shift) => {
              const isExpanded = expandedShiftId === shift.id;
              const isCurrentOpen = shift.status === "open";
              const shiftSales = getSalesForShift(shift.id);

              return (
                <div
                  key={shift.id}
                  className={`bg-white rounded-2xl border ${
                    isCurrentOpen ? "border-emerald-100 shadow-emerald-50/10 shadow-lg" : "border-slate-100"
                  } overflow-hidden transition-all duration-200`}
                >
                  {/* Shift Item Header Row */}
                  <div
                    onClick={() => toggleExpandShift(shift.id)}
                    className="p-4 flex items-center justify-between gap-4 cursor-pointer hover:bg-slate-50/50 transition-colors"
                  >
                    <div className="text-right space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-extrabold text-slate-800">
                          {formatOnlyDate(shift.startTime)}
                        </span>
                        {isCurrentOpen ? (
                          <span className="text-[9px] font-black bg-emerald-50 text-emerald-600 px-2 py-0.5 rounded-full border border-emerald-100">
                            مفتوح حالياً
                          </span>
                        ) : (
                          <span className="text-[9px] font-black bg-slate-50 text-slate-500 px-2 py-0.5 rounded-full border border-slate-100">
                            مغلقة ومسلمة
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-slate-400 font-medium">
                        من {new Date(shift.startTime).toLocaleTimeString("ar-IQ", { hour: '2-digit', minute: '2-digit', hour12: true })}
                        {shift.endTime && ` إلى ${new Date(shift.endTime).toLocaleTimeString("ar-IQ", { hour: '2-digit', minute: '2-digit', hour12: true })}`}
                      </p>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="text-left">
                        <p className="text-[9px] text-slate-400 font-bold">مبيعات الوردية</p>
                        <p className="text-xs font-black text-rose-500 font-mono">
                          {formatPrice(isCurrentOpen ? activeShiftSalesTotal : shift.salesTotal)}
                        </p>
                      </div>

                      {onDeleteShift && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setShiftToDelete(shift);
                          }}
                          className="w-8 h-8 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 flex items-center justify-center transition-colors cursor-pointer shrink-0"
                          title="حذف سجل الوردية"
                        >
                          <span className="material-symbols-outlined !text-base">delete</span>
                        </button>
                      )}

                      <span className={`material-symbols-outlined text-slate-400 transition-transform ${isExpanded ? "rotate-180" : ""}`}>
                        keyboard_arrow_down
                      </span>
                    </div>
                  </div>

                  {/* Shift Expanded details (Sales belonging to it) */}
                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div
                        initial={{ height: 0 }}
                        animate={{ height: "auto" }}
                        exit={{ height: 0 }}
                        className="overflow-hidden bg-slate-50/60 border-t border-slate-100"
                      >
                        <div className="p-4 space-y-3">
                          {/* Financial Summary */}
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 bg-white p-3.5 rounded-xl border border-slate-100 text-xs">
                            <div>
                              <span className="text-[10px] text-slate-400 font-bold block">رصيد الصندوق عند الفتح</span>
                              <span className="font-extrabold text-slate-700 font-mono">{formatPrice(shift.startBalance)}</span>
                            </div>
                            <div>
                              <span className="text-[10px] text-slate-400 font-bold block">مجموع المبيعات الصافية</span>
                              <span className="font-extrabold text-rose-500 font-mono">
                                {formatPrice(isCurrentOpen ? activeShiftSalesTotal : shift.salesTotal)}
                              </span>
                            </div>
                            <div>
                              <span className="text-[10px] text-slate-400 font-bold block">عدد الفواتير الصادرة</span>
                              <span className="font-extrabold text-slate-700 font-mono">
                                {isCurrentOpen ? activeShiftSalesCount : shift.salesCount} فواتير
                              </span>
                            </div>
                            <div>
                              <span className="text-[10px] text-slate-400 font-bold block">رصيد الصندوق عند الإغلاق</span>
                              <span className="font-extrabold text-slate-700 font-mono">
                                {isCurrentOpen ? "لم يتم الإغلاق" : formatPrice(shift.endBalance || 0)}
                              </span>
                            </div>
                          </div>

                          {/* List of individual Sales under this shift */}
                          <div className="space-y-2">
                            <span className="text-[10px] font-black text-slate-400 block text-right pr-0.5">فواتير هذه الوردية</span>
                            {shiftSales.length === 0 ? (
                              <p className="text-[10px] text-slate-400 font-semibold text-center py-4 bg-white rounded-xl border border-dashed border-slate-200">
                                لا توجد مبيعات مسجلة في هذه الوردية حتى الآن.
                              </p>
                            ) : (
                              <div className="space-y-1.5 max-h-[220px] overflow-y-auto no-scrollbar">
                                {shiftSales.map((sale) => (
                                  <div
                                    key={sale.id}
                                    onClick={() => setSelectedSale(sale)}
                                    className="bg-white rounded-xl p-3 border border-slate-100 flex items-center justify-between text-xs hover:border-rose-100 transition-colors cursor-pointer"
                                  >
                                    <div className="text-right">
                                      <span className="font-black text-slate-800 font-mono">#{String(sale.orderNum).padStart(4, "0")}</span>
                                      <span className="text-[10px] text-slate-400 font-medium mr-2">
                                        {new Date(sale.timestamp).toLocaleTimeString("ar-IQ", { hour: '2-digit', minute: '2-digit', hour12: true })}
                                      </span>
                                      <p className="text-[10px] text-slate-500 truncate max-w-[200px] mt-0.5">
                                        {sale.items.map((it) => `${it.name} (${it.quantity})`).join(" ، ")}
                                      </p>
                                    </div>
                                    <span className="font-black text-rose-500 font-mono">{formatPrice(sale.totalAmount)}</span>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* MODAL: OPEN SHIFT DIALOG */}
      <AnimatePresence>
        {showOpenConfirm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-slate-900/40 backdrop-blur-xs">
            <div className="absolute inset-0" onClick={() => setShowOpenConfirm(false)}></div>
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white w-full max-w-sm rounded-[32px] p-6 relative flex flex-col z-10 border border-slate-100 shadow-2xl text-right"
            >
              <div className="w-12 h-12 bg-rose-50 text-rose-500 flex items-center justify-center rounded-2xl mb-3">
                <span className="material-symbols-outlined !text-2xl">key</span>
              </div>
              <h3 className="font-extrabold text-slate-800 text-base mb-1">فتح نقطة بيع جديدة (وردية جديدة)</h3>
              <p className="text-xs text-slate-500 leading-relaxed mb-4">
                يرجى إدخال الرصيد النقدي المتوفر بصندوق النقدية (الكاشير) الآن كعهدة بداية شفت.
              </p>

              <form onSubmit={handleOpenShiftSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-extrabold text-slate-500 mb-1.5">رصيد البداية للصندوق (اختياري)</label>
                  <input
                    type="number"
                    placeholder="مثال: 50,000 أو اتركه 0"
                    value={startBalanceInput}
                    onChange={(e) => setStartBalanceInput(e.target.value === "" ? "" : Number(e.target.value))}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500 font-mono text-right"
                  />
                </div>

                <div className="flex gap-2.5 pt-2">
                  <button
                    type="submit"
                    className="flex-1 py-3 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-2xl text-xs transition-all shadow-md shadow-rose-200 cursor-pointer"
                  >
                    تأكيد فتح الوردية
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowOpenConfirm(false)}
                    className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl text-xs transition-all cursor-pointer"
                  >
                    تراجع
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL: CLOSE SHIFT DIALOG */}
      <AnimatePresence>
        {showCloseConfirm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-slate-900/40 backdrop-blur-xs">
            <div className="absolute inset-0" onClick={() => setShowCloseConfirm(false)}></div>
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white w-full max-w-sm rounded-[32px] p-6 relative flex flex-col z-10 border border-slate-100 shadow-2xl text-right"
            >
              <div className="w-12 h-12 bg-rose-50 text-rose-500 flex items-center justify-center rounded-2xl mb-3">
                <span className="material-symbols-outlined !text-2xl">logout</span>
              </div>
              <h3 className="font-extrabold text-slate-800 text-base mb-1">إغلاق نقطة البيع الحالية</h3>
              <p className="text-xs text-slate-500 leading-relaxed mb-4">
                تأكيد إنهاء الوردية الحالية وتسليم الصندوق. سيتم احتساب إجمالي مبيعاتك النقدية وقفله لحفظ التقارير.
              </p>

              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100/50 text-xs space-y-1.5 mb-4">
                <div className="flex justify-between font-bold">
                  <span className="text-slate-400">إجمالي المبيعات المحققة:</span>
                  <span className="text-slate-700 font-mono">{formatPrice(activeShiftSalesTotal)}</span>
                </div>
                <div className="flex justify-between font-bold">
                  <span className="text-slate-400">المبلغ الإجمالي المتوقع بالصندوق:</span>
                  <span className="text-rose-500 font-mono">{formatPrice(expectedEndBalance)}</span>
                </div>
              </div>

              <form onSubmit={handleCloseShiftSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-extrabold text-slate-500 mb-1.5">الرصيد الفعلي المتواجد في الصندوق (الدرج)</label>
                  <input
                    type="number"
                    placeholder={`المبلغ الفعلي (الافتراضي: ${expectedEndBalance})`}
                    value={endBalanceInput}
                    onChange={(e) => setEndBalanceInput(e.target.value === "" ? "" : Number(e.target.value))}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500 font-mono text-right"
                  />
                </div>

                <div className="flex gap-2.5 pt-2">
                  <button
                    type="submit"
                    className="flex-1 py-3 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-2xl text-xs transition-all shadow-md shadow-rose-200 cursor-pointer"
                  >
                    تأكيد إغلاق الوردية
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowCloseConfirm(false)}
                    className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl text-xs transition-all cursor-pointer"
                  >
                    تراجع
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL: SINGLE SALE DETAILED VIEW */}
      <AnimatePresence>
        {selectedSale && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-6 bg-slate-900/40 backdrop-blur-xs">
            <div className="absolute inset-0" onClick={() => setSelectedSale(null)}></div>
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white w-full max-w-md rounded-[32px] shadow-2xl p-6 relative flex flex-col z-10 border border-slate-100"
            >
              <div className="text-center pb-4 border-b border-dashed border-slate-200">
                <h3 className="font-extrabold text-slate-800 text-lg">{APP_CONFIG.storeName}</h3>
                <p className="text-[10px] text-slate-400 font-semibold">{APP_CONFIG.storeSubName}</p>
                <span className="mt-3 inline-block text-xs bg-slate-100 text-slate-600 font-black px-3 py-1 rounded-full font-mono">
                  فاتورة #{String(selectedSale.orderNum).padStart(4, "0")}
                </span>
              </div>

              <div className="py-3 text-xs text-slate-500 space-y-1.5 border-b border-slate-100 text-right">
                <div className="flex justify-between font-semibold">
                  <span>تاريخ البيع:</span>
                  <span className="text-slate-700 font-mono">{formatDate(selectedSale.timestamp)}</span>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto py-4 max-h-[25vh] space-y-3 no-scrollbar border-b border-dashed border-slate-200">
                {selectedSale.items.map((it, idx) => (
                  <div key={idx} className="flex justify-between items-start text-xs">
                    <div className="min-w-0 flex-1 mr-1 text-right">
                      <p className="font-bold text-slate-800 truncate">{it.name}</p>
                      <p className="text-[10px] text-slate-400 font-semibold">{it.brand} × {it.quantity}</p>
                    </div>
                    <span className="font-bold text-slate-700 shrink-0 font-mono">
                      {formatPrice(it.total)}
                    </span>
                  </div>
                ))}
              </div>

              <div className="py-4 flex justify-between items-center">
                <span className="text-sm font-bold text-slate-800">المبلغ الإجمالي:</span>
                <span className="text-lg font-black text-rose-600 font-mono tracking-tight">
                  {formatPrice(selectedSale.totalAmount)}
                </span>
              </div>

              <button
                onClick={() => setSelectedSale(null)}
                className="w-full py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl text-xs transition-colors cursor-pointer"
              >
                إغلاق
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      {/* MODAL: SHIFT DELETE CONFIRMATION */}
      <AnimatePresence>
        {shiftToDelete && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-slate-900/40 backdrop-blur-xs">
            <div className="absolute inset-0" onClick={() => setShiftToDelete(null)}></div>
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white w-full max-w-sm rounded-[32px] p-6 relative flex flex-col z-10 border border-slate-100 shadow-2xl text-right animate-in fade-in zoom-in-95 duration-200"
            >
              <div className="w-12 h-12 bg-rose-50 text-rose-500 flex items-center justify-center rounded-2xl mb-3">
                <span className="material-symbols-outlined !text-2xl">delete</span>
              </div>
              <h3 className="font-extrabold text-slate-800 text-base mb-1">حذف سجل الوردية؟</h3>
              <p className="text-xs text-slate-500 leading-relaxed mb-4">
                هل أنت متأكد من رغبتك في حذف سجل الوردية ليوم <span className="font-bold text-slate-700">{formatOnlyDate(shiftToDelete.startTime)}</span>؟ سيتم مسح هذا السجل نهائياً من قاعدة البيانات.
              </p>

              <div className="flex gap-2.5">
                <button
                  type="button"
                  onClick={async () => {
                    if (onDeleteShift && shiftToDelete) {
                      await onDeleteShift(shiftToDelete.id);
                      setShiftToDelete(null);
                    }
                  }}
                  className="flex-1 py-3 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-2xl text-xs transition-all shadow-md shadow-rose-200 cursor-pointer"
                >
                  تأكيد الحذف
                </button>
                <button
                  type="button"
                  onClick={() => setShiftToDelete(null)}
                  className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl text-xs transition-all cursor-pointer"
                >
                  تراجع
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

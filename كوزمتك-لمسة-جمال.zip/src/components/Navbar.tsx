/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import { ActiveTab } from "../types";
import { ShoppingBag, Package, FolderTree, Sliders } from "lucide-react";

interface NavbarProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  lowStockCount: number;
}

const NAV_ITEMS = [
  { id: "sale" as ActiveTab, label: "البيع المباشر", icon: ShoppingBag },
  { id: "products" as ActiveTab, label: "المنتجات", icon: Package },
  { id: "categories" as ActiveTab, label: "التصنيفات", icon: FolderTree },
  { id: "settings" as ActiveTab, label: "الإعدادات", icon: Sliders }
];

export default function Navbar({ activeTab, onTabChange, lowStockCount }: NavbarProps) {
  return (
    <nav
      id="bottom-navbar"
      className="absolute bottom-0 left-0 right-0 z-30 bg-white border-t border-[#EFE7E9] flex items-center justify-around h-[72px] px-3 shadow-sm select-none"
    >
      {NAV_ITEMS.map((item) => {
        const isActive = activeTab === item.id;
        const IconComponent = item.icon;
        
        return (
          <button
            key={item.id}
            id={`nav-tab-${item.id}`}
            onClick={() => onTabChange(item.id)}
            className="relative flex flex-col items-center justify-center flex-1 h-full py-1 focus:outline-none cursor-pointer transition-all active:scale-[0.98]"
          >
            {/* Top small indicator line */}
            {isActive && (
              <motion.div
                layoutId="activeTabIndicatorLine"
                className="absolute top-0 w-8 h-[3px] bg-[#7B0F3A] rounded-full"
                transition={{ type: "spring", stiffness: 350, damping: 28 }}
              />
            )}

            <div className="relative flex flex-col items-center justify-center">
              <div
                className={`flex items-center justify-center p-2 rounded-xl transition-all duration-200 ${
                  isActive 
                    ? "text-[#7B0F3A]" 
                    : "text-slate-400 hover:text-slate-600"
                }`}
              >
                <IconComponent 
                  className={`w-5 h-5 transition-transform duration-200 ${
                    isActive ? "scale-110 stroke-[2.25px]" : "stroke-[1.75px]"
                  }`} 
                />
              </div>

              {/* Dot badge for products tab if we have low-stock items */}
              {item.id === "products" && lowStockCount > 0 && (
                <span className="absolute top-0 right-3.5 w-2 h-2 bg-danger rounded-full ring-2 ring-white animate-pulse" />
              )}

              {/* Label */}
              <span
                className={`text-[10px] font-bold mt-0.5 tracking-wide transition-colors duration-200 ${
                  isActive ? "text-[#7B0F3A] font-extrabold" : "text-slate-400"
                }`}
              >
                {item.label}
              </span>
            </div>
          </button>
        );
      })}
    </nav>
  );
}

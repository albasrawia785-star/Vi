/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { SaleItem } from "../types";
import { APP_CONFIG } from "../config";

interface CartSheetProps {
  isOpen: boolean;
  cart: SaleItem[];
  onClose: () => void;
  onUpdateQty: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
  onCheckout: (discount: number) => void;
}

export default function CartSheet({
  isOpen,
  cart,
  onClose,
  onUpdateQty,
  onRemoveItem,
  onClearCart,
  onCheckout
}: CartSheetProps) {
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [discountStr, setDiscountStr] = useState<string>("");

  const discountVal = parseFloat(discountStr) || 0;

  const formatPrice = (price: number) => {
    return price.toLocaleString("en-US") + " د.ع";
  };

  const totalAmount = cart.reduce((sum, item) => sum + item.total, 0);
  const totalItemsCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const finalAmount = Math.max(0, totalAmount - discountVal);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-40 flex items-end justify-center select-none">
          {/* Backdrop Blur overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-900/40 backdrop-blur-xs"
          />

          {/* Bottom Sheet Drawer */}
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 350 }}
            className="relative w-full max-w-lg bg-white rounded-t-[32px] shadow-2xl flex flex-col max-h-[85vh] z-10"
          >
            {/* Grab handle bar for M3 sheet */}
            <div className="flex justify-center py-3 shrink-0">
              <div className="w-12 h-1.5 bg-slate-200 rounded-full"></div>
            </div>

            {/* Header */}
            <div className="flex items-center justify-between px-6 pb-4 border-b border-[#EFE7E9] shrink-0">
              <div className="flex items-center gap-2 flex-row-reverse text-right">
                <div className="w-10 h-10 rounded-full bg-[#7B0F3A]/5 flex items-center justify-center text-[#7B0F3A] shrink-0">
                  <span className="material-symbols-outlined font-bold">shopping_basket</span>
                </div>
                <div>
                  <h3 className="font-bold text-[#252525] text-sm">سلة المبيعات الحالية</h3>
                  <p className="text-[10px] text-slate-400 font-medium">{totalItemsCount} قطع مختارة</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {cart.length > 0 && (
                  <button
                    id="btn-cart-clear"
                    onClick={() => setShowClearConfirm(true)}
                    className="flex items-center gap-1 text-[11px] font-bold text-danger hover:bg-red-50 px-3 py-1.5 rounded-xl transition-colors cursor-pointer"
                  >
                    <span className="material-symbols-outlined !text-sm">delete_sweep</span>
                    تفريغ السلة
                  </button>
                )}
                <button
                  id="btn-cart-close"
                  onClick={onClose}
                  className="w-10 h-10 rounded-full bg-slate-50 hover:bg-slate-100 flex items-center justify-center text-slate-500 transition-colors cursor-pointer"
                >
                  <span className="material-symbols-outlined">close</span>
                </button>
              </div>
            </div>

            {/* Cart Body */}
            <div className="flex-1 overflow-y-auto px-6 py-4 space-y-3 no-scrollbar">
              {cart.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 text-center">
                  <div className="w-20 h-20 rounded-full bg-[#FCFAF8] flex items-center justify-center text-slate-300 mb-4 animate-bounce">
                    <span className="material-symbols-outlined !text-4xl">shopping_cart_off</span>
                  </div>
                  <h4 className="font-bold text-xs text-slate-700 mb-1">السلة فارغة حالياً</h4>
                  <p className="text-[10px] text-slate-400 max-w-xs leading-relaxed">
                    اضغط على المنتجات المتوفرة في واجهة البيع لإضافتها مباشرة وبدء عملية البيع.
                  </p>
                </div>
              ) : (
                cart.map((item) => (
                  <div
                    key={item.productId}
                    className="flex items-center justify-between p-3.5 bg-white rounded-2xl border border-[#EFE7E9] shadow-3xs"
                  >
                    {/* Delete Item Button */}
                    <button
                      id={`btn-cart-remove-${item.productId}`}
                      onClick={() => onRemoveItem(item.productId)}
                      className="w-8 h-8 rounded-xl bg-red-50 hover:bg-red-100 text-danger flex items-center justify-center shrink-0 transition-colors cursor-pointer"
                    >
                      <span className="material-symbols-outlined !text-lg">delete</span>
                    </button>

                    {/* Quantity Edit Controls */}
                    <div className="flex items-center bg-[#FCFAF8] border border-[#EFE7E9] rounded-xl p-1 gap-1.5 shrink-0 select-none mx-2">
                      <button
                        id={`btn-cart-dec-${item.productId}`}
                        type="button"
                        onClick={() => onUpdateQty(item.productId, item.quantity - 1)}
                        className="w-8 h-8 rounded-lg bg-white hover:bg-slate-100 flex items-center justify-center text-slate-600 font-bold active:scale-90 transition-all cursor-pointer border border-[#EFE7E9]/40"
                      >
                        <span className="material-symbols-outlined !text-base">remove</span>
                      </button>

                      <span className="text-xs font-bold text-slate-800 w-6 text-center font-mono">
                        {item.quantity}
                      </span>

                      <button
                        id={`btn-cart-inc-${item.productId}`}
                        type="button"
                        onClick={() => onUpdateQty(item.productId, item.quantity + 1)}
                        className="w-8 h-8 rounded-lg bg-[#7B0F3A] hover:bg-[#5C0B2B] flex items-center justify-center text-white font-bold active:scale-90 transition-all cursor-pointer"
                      >
                        <span className="material-symbols-outlined !text-base">add</span>
                      </button>
                    </div>

                    {/* Item Details */}
                    <div className="flex-1 text-right min-w-0 pr-1">
                      <h4 className="font-bold text-xs text-slate-800 leading-snug break-words">
                        {item.name}
                      </h4>
                      <p className="text-[9px] text-slate-400 font-medium mt-0.5">{item.brand}</p>
                      <span className="inline-block text-xs font-bold text-[#7B0F3A] font-mono mt-1">
                        {formatPrice(item.price)}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Footer Summary & Checkout */}
            {cart.length > 0 && (
              <div className="p-6 bg-[#FCFAF8] border-t border-[#EFE7E9] space-y-3 shrink-0 rounded-t-3xl">
                {/* Discount Input Block */}
                <div className="flex items-center justify-between gap-3 p-3 bg-white border border-[#EFE7E9] rounded-xl flex-row-reverse">
                  <span className="text-[11px] font-bold text-slate-700 shrink-0">تطبيق خصم مخصص (د.ع):</span>
                  <input
                    id="cart-discount-input"
                    type="number"
                    min="0"
                    placeholder="0"
                    value={discountStr}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (!val || parseFloat(val) >= 0) {
                        setDiscountStr(val);
                      }
                    }}
                    className="w-28 h-8 px-2 bg-[#FCFAF8] border border-[#EFE7E9] rounded-lg text-xs font-bold text-left font-mono focus:outline-none focus:border-[#7B0F3A] focus:ring-1 focus:ring-[#7B0F3A]/20"
                  />
                </div>

                {/* Calculations Breakdown */}
                <div className="space-y-1.5 pt-1">
                  <div className="flex justify-between text-[11px] text-slate-500 font-medium flex-row-reverse">
                    <span>مجموع السلة:</span>
                    <span className="font-bold text-slate-700 font-mono">{formatPrice(totalAmount)}</span>
                  </div>
                  {discountVal > 0 && (
                    <div className="flex justify-between text-[11px] text-danger font-medium flex-row-reverse">
                      <span>الخصم المطبق:</span>
                      <span className="font-bold font-mono">-{formatPrice(discountVal)}</span>
                    </div>
                  )}
                  <div className="flex justify-between items-center pt-2.5 border-t border-slate-200 flex-row-reverse">
                    <span className="font-bold text-slate-800 text-xs">الإجمالي النهائي للبيع:</span>
                    <span className="text-lg font-bold text-[#7B0F3A] font-mono tracking-tight">
                      {formatPrice(finalAmount)}
                    </span>
                  </div>
                </div>

                {/* Confirm Sale Button */}
                <button
                  id="btn-cart-checkout"
                  type="button"
                  onClick={() => {
                    onCheckout(discountVal);
                    setDiscountStr("");
                  }}
                  className="btn-ripple w-full h-12 bg-[#7B0F3A] hover:bg-[#5C0B2B] text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-xs active:scale-98 transition-all"
                >
                  <span className="material-symbols-outlined !text-lg">payments</span>
                  تأكيد البيع وإصدار الفاتورة
                </button>
              </div>
            )}

            {/* Custom Embedded Confirm Dialog for empty cart to avoid window.confirm */}
            <AnimatePresence>
              {showClearConfirm && (
                <div className="absolute inset-0 z-50 flex items-center justify-center p-6 bg-slate-950/40 backdrop-blur-xs rounded-t-[32px]">
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-xl text-center space-y-4 border border-border-custom"
                  >
                    <div className="w-12 h-12 rounded-full bg-red-50 text-danger flex items-center justify-center mx-auto">
                      <span className="material-symbols-outlined !text-3xl">warning</span>
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-800 text-sm">تفريغ سلة المبيعات؟</h4>
                      <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                        هل أنت متأكد من رغبتك في إفراغ السلة بالكامل وحذف كافة المنتجات المحددة؟
                      </p>
                    </div>
                    <div className="flex gap-3 pt-2">
                      <button
                        id="btn-confirm-clear-yes"
                        onClick={() => {
                          onClearCart();
                          setShowClearConfirm(false);
                        }}
                        className="flex-1 py-2 bg-danger hover:bg-[#C21C1C] text-white rounded-lg font-bold text-xs transition-colors cursor-pointer"
                      >
                        نعم، تفريغ
                      </button>
                      <button
                        id="btn-confirm-clear-no"
                        onClick={() => setShowClearConfirm(false)}
                        className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg font-bold text-xs transition-colors cursor-pointer"
                      >
                        إلغاء
                      </button>
                    </div>
                  </motion.div>
                </div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Product, Category, StoreSettings, POSShift } from "../types";
import { INITIAL_CATEGORIES, INITIAL_PRODUCTS, APP_CONFIG } from "../config";

const DB_NAME = "BeautyTouchPOS_DB_v3";
const DB_VERSION = 2;

export function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => {
      reject(request.error);
    };

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onupgradeneeded = (event) => {
      const db = request.result;

      let productsStore: IDBObjectStore;
      if (!db.objectStoreNames.contains("products")) {
        productsStore = db.createObjectStore("products", { keyPath: "id" });
      } else {
        productsStore = request.transaction!.objectStore("products");
      }

      // Create indexes if they don't exist
      if (!productsStore.indexNames.contains("name")) {
        productsStore.createIndex("name", "name", { unique: false });
      }
      if (!productsStore.indexNames.contains("categoryId")) {
        productsStore.createIndex("categoryId", "categoryId", { unique: false });
      }
      if (!productsStore.indexNames.contains("barcode")) {
        productsStore.createIndex("barcode", "barcode", { unique: false });
      }
      if (!productsStore.indexNames.contains("quantity")) {
        productsStore.createIndex("quantity", "quantity", { unique: false });
      }
      if (!productsStore.indexNames.contains("stock")) {
        productsStore.createIndex("stock", "quantity", { unique: false });
      }
      if (!productsStore.indexNames.contains("createdAt")) {
        productsStore.createIndex("createdAt", "createdAt", { unique: false });
      }
      if (!productsStore.indexNames.contains("updatedAt")) {
        productsStore.createIndex("updatedAt", "updatedAt", { unique: false });
      }

      if (!db.objectStoreNames.contains("categories")) {
        db.createObjectStore("categories", { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains("sales")) {
        db.createObjectStore("sales", { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains("settings")) {
        db.createObjectStore("settings", { keyPath: "key" });
      }
      if (!db.objectStoreNames.contains("shifts")) {
        db.createObjectStore("shifts", { keyPath: "id" });
      }
    };
  });
}

export async function seedDatabaseIfEmpty(): Promise<void> {
  const db = await openDB();

  const getCount = (database: IDBDatabase, storeName: string): Promise<number> => {
    return new Promise((resolve, reject) => {
      const tx = database.transaction(storeName, "readonly");
      const store = tx.objectStore(storeName);
      const request = store.count();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  };

  const categoriesCount = await getCount(db, "categories");
  if (categoriesCount === 0) {
    const tx = db.transaction(["categories", "products", "settings"], "readwrite");
    
    // Seed Categories
    const categoriesStore = tx.objectStore("categories");
    for (const cat of INITIAL_CATEGORIES) {
      categoriesStore.put({
        id: cat.id,
        name: cat.name,
        icon: cat.icon,
        createdAt: Date.now()
      });
    }

    // Seed Products
    const productsStore = tx.objectStore("products");
    INITIAL_PRODUCTS.forEach((prod, index) => {
      const id = `prod_${Date.now()}_${index}`;
      productsStore.put({
        id,
        name: prod.name,
        brand: prod.brand,
        categoryId: prod.categoryId,
        price: prod.price,
        quantity: prod.quantity,
        lowStockThreshold: prod.lowStockThreshold,
        description: prod.description,
        image: "",
        barcode: prod.barcode,
        createdAt: Date.now() - (index * 60000)
      });
    });

    // Seed Settings
    const settingsStore = tx.objectStore("settings");
    settingsStore.put({
      key: "store_settings",
      defaultLowStockThreshold: APP_CONFIG.defaultLowStockThreshold,
      marketingText: APP_CONFIG.marketingText,
      onboardingCompleted: false
    });

    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
}

export async function clearDatabase(): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(["products", "categories", "sales", "settings", "shifts"], "readwrite");
    tx.objectStore("products").clear();
    tx.objectStore("categories").clear();
    tx.objectStore("sales").clear();
    tx.objectStore("settings").clear();
    tx.objectStore("shifts").clear();

    tx.oncomplete = () => {
      seedDatabaseIfEmpty().then(() => resolve());
    };
    tx.onerror = () => reject(tx.error);
  });
}

export function compressAndResizeImage(base64OrFile: File | string, maxWidth = 300, maxHeight = 400): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    
    const onLoad = () => {
      let width = img.width;
      let height = img.height;

      if (width > height) {
        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }
      } else {
        if (height > maxHeight) {
          width = Math.round((width * maxHeight) / height);
          height = maxHeight;
        }
      }

      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext("2d");
      if (!ctx) {
        reject(new Error("Could not get 2D context"));
        return;
      }

      ctx.drawImage(img, 0, 0, width, height);
      const compressedDataUrl = canvas.toDataURL("image/jpeg", 0.7);
      resolve(compressedDataUrl);
    };

    img.onerror = (err) => {
      reject(err);
    };

    if (base64OrFile instanceof File) {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          img.src = e.target.result as string;
        }
      };
      reader.readAsDataURL(base64OrFile);
    } else {
      img.src = base64OrFile;
    }
    
    img.onload = onLoad;
  });
}

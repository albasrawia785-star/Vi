/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { doc, getDoc } from "firebase/firestore";
import { db, isFirebaseAvailable } from "../firebase/firebase-config";
import { verifyLicense } from "./license-service";

export interface UserSession {
  username: string;
  role: "manager" | "cashier";
}

export interface LoginResult {
  success: boolean;
  user?: UserSession;
  error?: string;
}

/**
 * Authenticates users (master administrator "ali", customer shop managers, or local cashier accounts).
 * Connects to Firestore to validate customers/licenses and caches credentials for offline access.
 */
export async function loginUser(
  usernameInput: string,
  passwordInput: string,
  activationCodeInput?: string
): Promise<LoginResult> {
  const username = usernameInput.trim();
  const password = passwordInput.trim();
  const activationCode = activationCodeInput ? activationCodeInput.trim() : "";

  if (!username) {
    return { success: false, error: "يرجى إدخال اسم المستخدم" };
  }

  // 1. Master System Administrator check (always works offline/online)
  if (username.toLowerCase() === "ali" && password === "0") {
    return {
      success: true,
      user: { username: "ali", role: "manager" }
    };
  }

  // 2. Client/Customer (Store Tenant) Check
  // Attempt Firestore customer check if online
  if (isFirebaseAvailable && db) {
    try {
      const docRef = doc(db, "customers", username.toLowerCase());
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        const data = docSnap.data();
        const dbPassword = data.password || "";
        const dbActivationCode = data.activationCode || "";
        const status = data.status || "active";
        const cosmeticName = data.cosmeticName || "كوزمتك لمسة جمال";
        const licenseType = data.licenseType || "تجريبي";
        const expireDate = data.expireDate || null;

        // A. Check Password
        if (password !== dbPassword) {
          return { success: false, error: "كلمة المرور غير صحيحة للعميل" };
        }

        // B. Check Activation Code (only if supplied as input, otherwise we auto-fill from db)
        if (activationCode && dbActivationCode.toLowerCase() !== activationCode.toLowerCase()) {
          return { success: false, error: "رمز التفعيل المدخل غير صحيح" };
        }

        // C. Check status
        if (status !== "active") {
          return { success: false, error: "عذراً، هذا الترخيص موقوف حالياً. يرجى مراجعة الإدارة." };
        }

        // D. Check Expiration
        if (licenseType === "تجريبي" || licenseType === "سنوي") {
          if (expireDate) {
            const expTime = new Date(expireDate).getTime();
            if (Date.now() > expTime) {
              return {
                success: false,
                error: licenseType === "تجريبي"
                  ? "انتهت صلاحية الفترة التجريبية. يرجى شراء ترخيص سنوي أو دائم."
                  : "انتهت صلاحية الترخيص السنوي. يرجى التجديد للاستمرار بالعمل."
              };
            }
          }
        }

        // Successful Online Authentication
        // Save customer state and activation code
        localStorage.setItem("pos_customer_username", username);
        localStorage.setItem("pos_activation_code", dbActivationCode);
        localStorage.setItem("pos_cosmetic_name", cosmeticName);

        // Cache credentials and license info for offline access
        const cachedLicense = {
          isValid: true,
          message: "الترخيص مفعل وصالح للعمل",
          cosmeticName,
          licenseType,
          expireDate,
          status,
          lastChecked: Date.now()
        };
        localStorage.setItem("pos_cached_license", JSON.stringify(cachedLicense));
        
        // Also cache the credentials specifically for login fallback
        localStorage.setItem("pos_cached_customer_creds", JSON.stringify({
          username: username.toLowerCase(),
          password,
          activationCode: dbActivationCode
        }));

        return {
          success: true,
          user: { username, role: "manager" }
        };
      }
    } catch (err) {
      console.warn("Could not login via online Firestore. Attempting offline fallback.", err);
    }
  }

  // Offline Customer Credentials Check fallback
  const offlineCredsStr = localStorage.getItem("pos_cached_customer_creds");
  if (offlineCredsStr) {
    try {
      const offlineCreds = JSON.parse(offlineCredsStr);
      if (
        offlineCreds.username === username.toLowerCase() &&
        offlineCreds.password === password
      ) {
        // If they provided an activation code, check it
        if (activationCode && offlineCreds.activationCode.toLowerCase() !== activationCode.toLowerCase()) {
          return { success: false, error: "رمز التفعيل المدخل غير صحيح" };
        }

        // Verify license state offline
        const license = await verifyLicense();
        if (!license.isValid) {
          return { success: false, error: license.message };
        }

        // Save login session
        localStorage.setItem("pos_customer_username", username);
        localStorage.setItem("pos_activation_code", offlineCreds.activationCode);

        return {
          success: true,
          user: { username, role: "manager" }
        };
      }
    } catch (e) {
      // Ignore parsing errors
    }
  }

  return {
    success: false,
    error: "اسم المستخدم أو كلمة المرور غير صحيحة أو الترخيص غير مفعل."
  };
}

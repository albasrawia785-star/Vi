/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  collection,
  getDocs,
  query,
  where
} from "firebase/firestore";
import { db, isFirebaseAvailable } from "../firebase/firebase-config";

export interface Customer {
  username: string;
  password?: string;
  activationCode: string;
  cosmeticName: string;
  ownerName: string;
  phone: string;
  licenseType: "تجريبي" | "سنوي" | "دائم";
  trialHours: number;
  expireDate: string | null;
  status: "active" | "suspended" | "inactive";
  createdAt: string;
  updatedAt: string;
}

export interface LicenseStatus {
  isValid: boolean;
  message: string;
  cosmeticName: string;
  licenseType: "تجريبي" | "سنوي" | "دائم";
  expireDate: string | null;
  status: string;
  lastChecked: number;
}

/**
 * Generates a random unique activation code of length 20 (5 blocks of 4 alphanumeric characters).
 * Example: A7F2-XQ91-MD84-PK22-ZZ99
 */
export function generateActivationCode(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  const segments: string[] = [];
  for (let i = 0; i < 5; i++) {
    let segment = "";
    for (let j = 0; j < 4; j++) {
      segment += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    segments.push(segment);
  }
  return segments.join("-");
}

/**
 * Generates a random unique activation code of 20 alphanumeric characters in the format AAAAA-BBBBB-CCCCC-DDDDD (4 blocks of 5).
 * This meets the 'AAAA-BBBB-CCCC-DDDD' block layout constraint while providing exactly 20 active key characters.
 */
export function generateFourBlockActivationCode(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  const segments: string[] = [];
  for (let i = 0; i < 4; i++) {
    let segment = "";
    for (let j = 0; j < 5; j++) {
      segment += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    segments.push(segment);
  }
  return segments.join("-");
}

/**
 * Retrieves or generates a unique stable device ID for the offline app instance.
 */
export function getDeviceId(): string {
  let devId = localStorage.getItem("pos_device_id");
  if (!devId) {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let randomPart = "";
    for (let i = 0; i < 8; i++) {
      randomPart += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    devId = `POS-${randomPart}`;
    localStorage.setItem("pos_device_id", devId);
  }
  return devId;
}

/**
 * Verifies the license of the currently logged-in customer.
 * Supports online validation via Firestore and offline validation via cached localStorage credentials.
 */
export async function verifyLicense(): Promise<LicenseStatus> {
  const username = localStorage.getItem("pos_customer_username");
  const activationCode = localStorage.getItem("pos_activation_code");

  // Default fallback if no customer is logged in yet
  if (!username) {
    const defaultCosmeticName = localStorage.getItem("pos_cosmetic_name") || "كوزمتك لمسة جمال";
    return {
      isValid: true,
      message: "لا يوجد مستخدم مسجل حالياً.",
      cosmeticName: defaultCosmeticName,
      licenseType: "دائم",
      expireDate: null,
      status: "active",
      lastChecked: Date.now()
    };
  }

  const cachedDataStr = localStorage.getItem("pos_cached_license");
  let cachedData: any = null;
  if (cachedDataStr) {
    try {
      cachedData = JSON.parse(cachedDataStr);
    } catch (e) {
      cachedData = null;
    }
  }

  // 1. Try checking online if Firebase is available
  if (isFirebaseAvailable && db) {
    try {
      // Find customer by username (document ID)
      const docRef = doc(db, "customers", username.trim().toLowerCase());
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        const data = docSnap.data() as Customer;
        
        const cosmeticName = data.cosmeticName || "كوزمتك لمسة جمال";
        const licenseType = data.licenseType || "تجريبي";
        const status = data.status || "active";
        const dbActivationCode = data.activationCode || "";
        const expireDateStr = data.expireDate;

        // A. Check activation code match
        if (activationCode && dbActivationCode && activationCode.trim() !== dbActivationCode.trim()) {
          return {
            isValid: false,
            message: "رمز التفعيل المدخل غير متطابق مع السجل السحابي.",
            cosmeticName,
            licenseType,
            expireDate: expireDateStr,
            status,
            lastChecked: Date.now()
          };
        }

        // B. Check status
        if (status !== "active") {
          return {
            isValid: false,
            message: "عذراً، هذا الترخيص موقوف حالياً. يرجى مراجعة الإدارة.",
            cosmeticName,
            licenseType,
            expireDate: expireDateStr,
            status,
            lastChecked: Date.now()
          };
        }

        // C. Check expiration
        let isValid = true;
        let msg = "الترخيص مفعل وصالح للعمل";

        if (licenseType === "تجريبي" || licenseType === "سنوي") {
          if (expireDateStr) {
            const expTime = new Date(expireDateStr).getTime();
            if (Date.now() > expTime) {
              isValid = false;
              msg = licenseType === "تجريبي" 
                ? "انتهت صلاحية الفترة التجريبية. يرجى شراء ترخيص سنوي أو دائم."
                : "انتهت صلاحية الترخيص السنوي. يرجى التجديد للاستمرار بالعمل.";
            }
          }
        }

        const finalStatus: LicenseStatus = {
          isValid,
          message: msg,
          cosmeticName,
          licenseType,
          expireDate: expireDateStr,
          status,
          lastChecked: Date.now()
        };

        // Cache the verified status
        localStorage.setItem("pos_cached_license", JSON.stringify(finalStatus));
        localStorage.setItem("pos_cosmetic_name", cosmeticName);

        return finalStatus;
      }
    } catch (err) {
      console.warn("Failed to check license online. Reverting to offline cache.", err);
    }
  }

  // 2. Offline Fallback using Cached License Info
  if (cachedData) {
    let isValid = cachedData.isValid;
    let msg = cachedData.message;

    // Verify expiration using offline clock
    if (cachedData.expireDate && (cachedData.licenseType === "تجريبي" || cachedData.licenseType === "سنوي")) {
      const expTime = new Date(cachedData.expireDate).getTime();
      if (Date.now() > expTime) {
        isValid = false;
        msg = cachedData.licenseType === "تجريبي"
          ? "انتهت صلاحية الفترة التجريبية (أوفلاين). يرجى الاتصال بالإنترنت لشراء ترخيص."
          : "انتهت صلاحية الترخيص السنوي (أوفلاين). يرجى الاتصال بالإنترنت للتجديد.";
      }
    }

    // Check status
    if (cachedData.status !== "active") {
      isValid = false;
      msg = "عذراً، هذا الترخيص موقوف حالياً (أوفلاين). يرجى الاتصال بالإنترنت للتفعيل.";
    }

    return {
      isValid,
      message: msg,
      cosmeticName: cachedData.cosmeticName || "كوزمتك لمسة جمال",
      licenseType: cachedData.licenseType || "تجريبي",
      expireDate: cachedData.expireDate,
      status: cachedData.status || "active",
      lastChecked: cachedData.lastChecked
    };
  }

  // 3. Absolute default if completely offline on first boot
  const defaultCosmeticName = localStorage.getItem("pos_cosmetic_name") || "كوزمتك لمسة جمال";
  return {
    isValid: true,
    message: "يعمل التطبيق بالوضع التجريبي الافتراضي (يرجى الاتصال بالإنترنت للتفعيل)",
    cosmeticName: defaultCosmeticName,
    licenseType: "تجريبي",
    expireDate: null,
    status: "active",
    lastChecked: Date.now()
  };
}

// ============================================================================
// ADMIN SERVICES (Customers and Licenses Management)
// ============================================================================

/**
 * Fetches all customer records from Firestore.
 */
export async function getAllCustomers(): Promise<Customer[]> {
  if (!isFirebaseAvailable || !db) return [];
  try {
    const colRef = collection(db, "customers");
    const snap = await getDocs(colRef);
    const list: Customer[] = [];
    snap.forEach((doc) => {
      list.push(doc.data() as Customer);
    });
    // Sort by createdAt descending
    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  } catch (err) {
    console.error("Failed to fetch customers from Firestore:", err);
    throw err;
  }
}

/**
 * Saves a new customer or updates an existing customer in Firestore.
 */
export async function saveCustomer(customer: Customer): Promise<void> {
  if (!isFirebaseAvailable || !db) throw new Error("Firebase is not available");
  try {
    const docId = customer.username.trim().toLowerCase();
    const docRef = doc(db, "customers", docId);
    
    // Ensure timestamps are correctly set
    const dataToSave = {
      ...customer,
      username: customer.username.trim(),
      updatedAt: new Date().toISOString()
    };

    await setDoc(docRef, dataToSave, { merge: true });
    console.log(`Saved customer: ${customer.username}`);
  } catch (err) {
    console.error("Failed to save customer to Firestore:", err);
    throw err;
  }
}

/**
 * Deletes a customer from Firestore.
 */
export async function deleteCustomer(username: string): Promise<void> {
  if (!isFirebaseAvailable || !db) throw new Error("Firebase is not available");
  try {
    const docId = username.trim().toLowerCase();
    const docRef = doc(db, "customers", docId);
    await deleteDoc(docRef);
    console.log(`Deleted customer: ${username}`);
  } catch (err) {
    console.error("Failed to delete customer from Firestore:", err);
    throw err;
  }
}

/**
 * Toggles a customer's status between active and suspended.
 */
export async function toggleCustomerStatus(username: string, currentStatus: "active" | "suspended" | "inactive"): Promise<void> {
  if (!isFirebaseAvailable || !db) throw new Error("Firebase is not available");
  try {
    const docId = username.trim().toLowerCase();
    const docRef = doc(db, "customers", docId);
    const newStatus = currentStatus === "active" ? "suspended" : "active";
    await updateDoc(docRef, {
      status: newStatus,
      updatedAt: new Date().toISOString()
    });
  } catch (err) {
    console.error("Failed to toggle customer status:", err);
    throw err;
  }
}

/**
 * Updates a customer's license type and recalculates expiration date.
 */
export async function updateCustomerLicense(
  username: string,
  licenseType: "تجريبي" | "سنوي" | "دائم",
  trialHoursInput?: number
): Promise<void> {
  if (!isFirebaseAvailable || !db) throw new Error("Firebase is not available");
  try {
    const docId = username.trim().toLowerCase();
    const docRef = doc(db, "customers", docId);

    let expireDate: string | null = null;
    const now = new Date();

    if (licenseType === "تجريبي") {
      const hours = trialHoursInput || 24;
      expireDate = new Date(now.getTime() + hours * 3600 * 1000).toISOString();
    } else if (licenseType === "سنوي") {
      expireDate = new Date(now.getTime() + 365 * 24 * 3600 * 1000).toISOString();
    }

    await updateDoc(docRef, {
      licenseType,
      trialHours: licenseType === "تجريبي" ? (trialHoursInput || 24) : 0,
      expireDate,
      updatedAt: now.toISOString()
    });
  } catch (err) {
    console.error("Failed to update customer license:", err);
    throw err;
  }
}

/**
 * Resets a customer's password in Firestore.
 */
export async function resetCustomerPassword(username: string, passwordInput: string): Promise<void> {
  if (!isFirebaseAvailable || !db) throw new Error("Firebase is not available");
  try {
    const docId = username.trim().toLowerCase();
    const docRef = doc(db, "customers", docId);
    await updateDoc(docRef, {
      password: passwordInput.trim(),
      updatedAt: new Date().toISOString()
    });
  } catch (err) {
    console.error("Failed to reset customer password:", err);
    throw err;
  }
}

/**
 * Generates a new random activation code and updates it in Firestore.
 */
export async function generateNewActivationCodeForCustomer(username: string): Promise<string> {
  if (!isFirebaseAvailable || !db) throw new Error("Firebase is not available");
  try {
    const docId = username.trim().toLowerCase();
    const docRef = doc(db, "customers", docId);
    const newCode = generateFourBlockActivationCode();
    await updateDoc(docRef, {
      activationCode: newCode,
      updatedAt: new Date().toISOString()
    });
    return newCode;
  } catch (err) {
    console.error("Failed to generate new activation code:", err);
    throw err;
  }
}

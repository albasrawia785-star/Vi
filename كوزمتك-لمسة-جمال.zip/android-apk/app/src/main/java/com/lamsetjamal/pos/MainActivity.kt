package com.lamsetjamal.pos

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.*
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.activity.EdgeToEdge
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var splashContainer: FrameLayout
    private lateinit var offlineContainer: LinearLayout
    private lateinit var btnRetry: Button

    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var pendingPermissionRequest: PermissionRequest? = null

    // Register file chooser activity launcher
    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (fileChooserCallback == null) return@registerForActivityResult
        val results = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
        fileChooserCallback?.onReceiveValue(results)
        fileChooserCallback = null
    }

    // Register camera permission launcher
    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            pendingPermissionRequest?.grant(pendingPermissionRequest?.resources)
        } else {
            pendingPermissionRequest?.deny()
        }
        pendingPermissionRequest = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // 1. Enable Android Edge-to-Edge using the latest AndroidX APIs.
        EdgeToEdge.enable(this)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 2. Make WebView layout extend fully behind status bar and navigation bar.
        WindowCompat.setDecorFitsSystemWindows(window, false)

        // 3. Ensure the layout handles display cutouts (notches) correctly.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        // Initialize Native Views
        webView = findViewById(R.id.webView)
        splashContainer = findViewById(R.id.splashContainer)
        offlineContainer = findViewById(R.id.offlineContainer)
        btnRetry = findViewById(R.id.btnRetry)

        // Setup Back Button Navigation within WebView
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })

        // Configure WebView and loads the application URL
        setupWebView()
        setupOfflineHandling()
        hideSystemBars()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // 4. Keep immersive mode active and automatically re-hide system bars when the app regains focus.
        if (hasFocus) {
            hideSystemBars()
        }
    }

    private fun hideSystemBars() {
        val windowInsetsController = WindowCompat.getInsetsController(window, window.decorView)
        // Configure system bars behavior to show transiently on swipe (Immersive Sticky Mode)
        windowInsetsController.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        // Hide both Status bar and Navigation bar
        windowInsetsController.hide(WindowInsetsCompat.Type.systemBars())
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val settings = webView.settings

        // Basic settings for modern PWA rendering
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.javaScriptCanOpenWindowsAutomatically = true
        settings.mediaPlaybackRequiresUserGesture = false

        // HTML5 Application Cache and IndexedDB configs
        settings.cacheMode = if (isNetworkAvailable()) WebSettings.LOAD_DEFAULT else WebSettings.LOAD_CACHE_ELSE_NETWORK
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            @Suppress("DEPRECATION")
            settings.databasePath = applicationContext.getDir("databases", Context.MODE_PRIVATE).path
        }

        // Handle mixed content on secure connections
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

        // Custom User Agent to support identifying our App Wrapper if needed
        val originalUA = settings.userAgentString
        settings.userAgentString = "$originalUA LamsetJamalAndroidAPK/1.0"

        // Setup Custom Clients
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // When PWA loaded, fade out the splash screen smoothly
                if (splashContainer.visibility == View.VISIBLE) {
                    splashContainer.animate()
                        .alpha(0f)
                        .setDuration(450)
                        .withEndAction {
                            splashContainer.visibility = View.GONE
                        }
                }
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                // Show offline state ONLY if the primary URL fails loading
                val failingUrl = request?.url?.toString() ?: ""
                val targetUrl = getString(R.string.pwa_url)
                if (failingUrl.startsWith(targetUrl) || request?.isForMainFrame == true) {
                    showOfflineScreen()
                }
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val url = request?.url?.toString() ?: return false
                val targetUrl = getString(R.string.pwa_url)

                // Open standard website routes in app, and external urls or intents in browser/maps/whatsapp
                return if (url.startsWith(targetUrl) || url.contains("ais-pre") || url.contains("ais-dev") || url.startsWith("file:///android_asset/")) {
                    false
                } else {
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        startActivity(intent)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                    true
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            // Overrides File Chooser for Image/Receipt uploading inside the PWA POS app
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = filePathCallback

                val intent = fileChooserParams?.createIntent()
                if (intent != null) {
                    try {
                        fileChooserLauncher.launch(intent)
                    } catch (e: Exception) {
                        fileChooserCallback?.onReceiveValue(null)
                        fileChooserCallback = null
                        return false
                    }
                }
                return true
            }

            // Overrides permission request (such as Camera used for scanning QR/barcodes inside cosmetics pos)
            override fun onPermissionRequest(request: PermissionRequest?) {
                val resources = request?.resources ?: return
                for (resource in resources) {
                    if (resource == PermissionRequest.RESOURCE_VIDEO_CAPTURE) {
                        pendingPermissionRequest = request
                        if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA)
                            == PackageManager.PERMISSION_GRANTED
                        ) {
                            request.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE))
                        } else {
                            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                        }
                        return
                    }
                }
                super.onPermissionRequest(request)
            }
        }

        // Load the main PWA URL
        val mainUrl = getString(R.string.pwa_url)
        webView.loadUrl(mainUrl)
    }

    private fun setupOfflineHandling() {
        btnRetry.setOnClickListener {
            // Reset state, display loader, and retry loading main PWA
            offlineContainer.visibility = View.GONE
            splashContainer.visibility = View.VISIBLE
            splashContainer.alpha = 1f
            webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
            webView.loadUrl(getString(R.string.pwa_url))
        }

        // Real-time network detection callback
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        connectivityManager.registerNetworkCallback(request, object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                super.onAvailable(network)
                runOnUiThread {
                    // If offline state was visible, auto-retry on internet recovery
                    if (offlineContainer.visibility == View.VISIBLE) {
                        btnRetry.performClick()
                    }
                }
            }
        })
    }

    private fun showOfflineScreen() {
        webView.visibility = View.INVISIBLE
        offlineContainer.visibility = View.VISIBLE
        splashContainer.visibility = View.GONE
    }

    private fun isNetworkAvailable(): Boolean {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}

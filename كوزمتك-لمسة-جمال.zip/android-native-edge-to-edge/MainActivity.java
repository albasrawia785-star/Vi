package io.ionic.starter; // TODO: Replace with your actual application package name (e.g. com.yourdomain.app)

import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import androidx.activity.EdgeToEdge;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // 1. Enable Android Edge-to-Edge using the latest AndroidX APIs.
        // This ensures the window is laid out behind system bars by default on all supported Android versions.
        EdgeToEdge.enable(this);
        
        super.onCreate(savedInstanceState);
        
        // 2. Make WebView extend behind the status bar and navigation bar.
        // Set fitsSystemWindows to false on the window to prevent system offsets/padding on container.
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);

        // 3. Ensure the layout handles display cutouts (notches) correctly.
        // Use SHORT_EDGES cutout mode so that the WebView extends fully into the notch area without black bars.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            getWindow().getAttributes().layoutInDisplayCutoutMode = 
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        // 4. Hide system bars initially using WindowInsetsControllerCompat
        hideSystemBars();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        // 5. Keep immersive mode active and automatically re-hide system bars when the app regains focus.
        if (hasFocus) {
            hideSystemBars();
        }
    }

    private void hideSystemBars() {
        WindowInsetsControllerCompat windowInsetsController = 
            WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        
        // Configure the behavior of hidden system bars to show transiently on swipe (immersive sticky mode)
        windowInsetsController.setSystemBarsBehavior(
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        );
        // Hide both the Status Bar and the Navigation Bar
        windowInsetsController.hide(WindowInsetsCompat.Type.systemBars());
    }
}
